﻿using System;
using System.Drawing;
using System.Windows.Forms;
using PEPlugin;

public class PE2BlenderReceiver : PEPluginClass {
 public override string Name { get { return "pe 2 blender"; } }
 public override string Version { get { return "1.0.0"; } }
 public override string Description { get { return "pe 2 blender - Blender PMX 同步预览接收"; } }
 static ReceiverWindow window;
 public PE2BlenderReceiver() { m_option=new PEPluginOption(false,true,"pe 2 blender"); }
 public override void Run(IPERunArgs args) {
  if(window==null||window.IsDisposed)window=new ReceiverWindow(args);
  window.Show();window.Activate();
 }
}
public sealed class ReceiverWindow : Form {
 readonly PreviewInbox inbox=new PreviewInbox(@"E:\New project\output\pe_preview_link\exchange");
 readonly IPERunArgs args;
 readonly Timer timer=new Timer();
 readonly Label status=new Label();
 public ReceiverWindow(IPERunArgs hostArgs) {
  args=hostArgs;Text="pe 2 blender";ClientSize=new Size(440,180);
  var explanation=new Label {Left=12,Top=12,Width=415,Height=50};
  explanation.Text="开始接收后，下一次 Blender 导出会替换当前 PE 中的模型。\n请将此 PE 窗口用于预览；物理播放仍在 PE 中操作。";
  var start=new Button {Left=12,Top=70,Width=200,Height=30,Text="开始接收预览副本"};
  var stop=new Button {Left=225,Top=70,Width=100,Height=30,Text="暂停"};
  status.SetBounds(12,112,415,55);status.Text="未接收。请先点击开始，再从 Blender 导出。";
  start.Click+=(s,e)=>{try{inbox.Begin();timer.Start();status.Text="等待 Blender 导出……";}catch(Exception ex){status.Text=ex.Message;}};
  stop.Click+=(s,e)=>{timer.Stop();inbox.Stop();status.Text="已暂停";};
  timer.Interval=300;
  timer.Tick+=(s,e)=>{
   timer.Stop();
   try {
    string result=inbox.Poll(args.Host.Connector.Pmx.CurrentPath,
     path=>args.Host.Connector.Form.OpenPMXFile(path));
    if(result=="loaded")status.Text="PMX 已重新读取。请在 TransformView 中复位／播放物理。";
    else if(result=="paused")status.Text="PE 已切换到其他模型，接收已暂停。";
    else if(result=="rejected")status.Text="PE 未完成加载。请检查提示后重新导出。";
    else if(result=="error")status.Text="接收失败："+inbox.LastError;
   } finally {if(inbox.Active&&!IsDisposed)timer.Start();}
  };
  Controls.AddRange(new Control[]{explanation,start,stop,status});
  FormClosed+=(s,e)=>{timer.Stop();timer.Dispose();inbox.Stop();};
 }
}
