bl_info={"name":"PE","author":"草履虫 / A4four","version":(1,5,1),"blender":(3,0,0),"location":"顶部工作区 > PE","description":"独立 PE 大纲和 MMD 数据编辑工作区，支持表情编辑与骨骼物理对齐","category":"Object"}
"""草履虫 MMD 数据工作区。右下 Properties 支持原生属性与绑定流程切换。"""
import bpy
import bmesh
import os
import uuid
import sys
import math
from mathutils import Matrix,Vector
from types import SimpleNamespace
if os.path.dirname(__file__) not in sys.path:sys.path.insert(0,os.path.dirname(__file__))
import caolvchong_mmd_validation as morph_api
import importlib
import caolvchong_morph_editor as morph_editor
from bpy_extras.io_utils import ImportHelper
from bpy.props import (BoolProperty, CollectionProperty, EnumProperty, FloatProperty,
                       IntProperty, PointerProperty, StringProperty, FloatVectorProperty)

WORKSPACE_NAME = "MMD Rig & Physics"  # Template datablock name; visible workspace is PE.
MARKER = "clm_mmd_workspace"
CATEGORIES = [
    ('INFO', '信息', '模型名称和注释', 'INFO', 6),
    ('MESH', '网格', '当前模型的网格对象', 'MESH_DATA', 7),
    ('MATERIAL', '材质', '材质与 MMD 材质设置', 'MATERIAL', 0),
    ('BONE', '骨骼', '骨骼与 MMD 属性', 'BONE_DATA', 1),
    ('COLLECTION', '骨骼集', 'Blender 骨骼集合，不是 MMD 显示枠', 'GROUP_BONE', 2),
    ('MORPH', '表情', '形态键与 MMD 表情分类', 'SHAPEKEY_DATA', 3),
    ('RIGID', '刚体', 'MMD 刚体', 'RIGID_BODY', 4),
    ('JOINT', 'Joint', 'MMD 刚体约束', 'CONSTRAINT', 5),
]
_refreshing = False
_pending_layout = []
_registered = False
_binding_states = {}
_binding_operator_methods = []
_binding_draw_skeleton = None
_binding_draw_physics = None
_native_selections = {}
_comment_split_pending = set()
_comment_needs_top = set()


def root_of(obj):
    seen = set()
    while obj and obj.as_pointer() not in seen:
        seen.add(obj.as_pointer())
        if getattr(obj, "mmd_type", "") == "ROOT":
            return obj
        obj = obj.parent
    return None


def model_objects(root, scene):
    return [o for o in scene.objects if root_of(o) == root] if root else []


def armature_of(root, scene):
    return next((o for o in model_objects(root, scene) if o.type == 'ARMATURE'), None)


def current_item(settings):
    return settings.items[settings.index] if 0 <= settings.index < len(settings.items) else None


def item_target(item):
    if not item:
        return None
    obj = item.obj
    if item.kind == 'MATERIAL':
        return item.material
    if not obj:
        return None
    if item.kind == 'BONE':
        return obj.pose.bones.get(item.key)
    if item.kind == 'COLLECTION':
        return obj.data.collections_all.get(item.key) if hasattr(obj.data, 'collections_all') else None
    if item.kind == 'MORPH':
        if item.key.startswith('@'):
            kind,name=_morph_identity(item);return morph_api.metadata(obj,kind,name)
        keys = getattr(obj.data, 'shape_keys', None)
        return keys.key_blocks.get(item.key) if keys else None
    return obj


def morph_meshes(root,name):
    """Owners of a single model-level vertex morph (including shared meshes)."""
    return [o for o in morph_api.meshes(root) if o.data.shape_keys and name in o.data.shape_keys.key_blocks] if root else []


def _rows(root, scene, category):
    if category == 'INFO':
        return []
    objects = model_objects(root, scene)
    arm = armature_of(root, scene)
    if category == 'MESH':
        return [(o.name, o, None, '') for o in objects
                if o.type == 'MESH' and getattr(o, 'mmd_type', 'NONE') == 'NONE']
    if category == 'BONE':
        return [(b.name, arm, None, b.name) for b in arm.pose.bones
                if not getattr(b, 'is_mmd_shadow_bone', False)] if arm else []
    if category == 'COLLECTION':
        return [(c.name, arm, None, c.name) for c in arm.data.collections_all] if arm and hasattr(arm.data, 'collections_all') else []
    if category == 'MORPH':
        rows=[];seen=set()
        for o in objects:
            if o.type!='MESH' or getattr(o,'mmd_type','NONE')!='NONE' or not o.data.shape_keys:continue
            for shape in o.data.shape_keys.key_blocks:
                if shape==o.data.shape_keys.reference_key or shape.name in seen:continue
                seen.add(shape.name);rows.append((shape.name,o,None,shape.name))
        labels={'bone_morphs':'骨骼','material_morphs':'材质','uv_morphs':'UV','group_morphs':'组合'}
        if root:
            rows.extend((m.name+' · '+labels[kind],root,None,'@'+kind+'|'+m.name)
                        for kind in labels for m in getattr(root.mmd_root,kind))
        return rows
    if category == 'MATERIAL':
        result, seen = [], set()
        for o in objects:
            if o.type != 'MESH' or getattr(o, 'mmd_type', 'NONE') != 'NONE':
                continue
            for mat in o.data.materials:
                if mat and mat.as_pointer() not in seen:
                    seen.add(mat.as_pointer())
                    result.append((mat.name, o, mat, ""))
        return result
    expected = 'RIGID_BODY' if category == 'RIGID' else 'JOINT'
    return [(o.name, o, None, "") for o in objects if getattr(o, 'mmd_type', '') == expected]


def refresh(context):
    """Refresh data only; never change Blender's selection or interaction mode."""
    global _refreshing
    if _refreshing or not hasattr(context.scene, MARKER):
        return
    s = context.scene.clm_mmd_workspace
    _refreshing = True
    try:
        candidate = root_of(context.object)
        if (not s.root or not s.lock_model) and candidate and candidate.name in context.scene.objects:
            s.root = candidate
        if not s.root:
            roots = [o for o in context.scene.objects if getattr(o, 'mmd_type', '') == 'ROOT']
            if len(roots) == 1:
                s.root = roots[0]
        if s.root and s.root.name not in context.scene.objects:
            rows = []
        else:
            rows = _rows(s.root, context.scene, s.category)
        def identity(obj, mat, key):
            if s.category=='MORPH':return (s.root.as_pointer() if s.root else 0,0,key)
            return (obj.as_pointer() if obj else 0, mat.as_pointer() if mat else 0, key)
        wanted = [(name, identity(obj, mat, key)) for name, obj, mat, key in rows]
        existing = [(i.name, identity(i.obj, i.material, i.key)) for i in s.items]
        root_stamp = str(s.root.as_pointer()) if s.root else ''
        same_scope = s.get('_category') == s.category and s.get('_root') == root_stamp
        checked = {identity(i.obj, i.material, i.key) for i in s.items if i.selected} if same_scope else set()
        was_empty = len(s.items) == 0
        if s.category == 'COLLECTION':
            refresh_collection_members(context, s)
        if same_scope and wanted == existing:
            if s.category=='MORPH':
                # The expression survives even if its representative mesh changes.
                for item,(_,obj,_,_) in zip(s.items,rows):item.obj=obj
            return
        old = current_item(s)
        old_identity = identity(old.obj, old.material, old.key) if old and old.kind == s.category else None
        s.items.clear()
        index = int(s.get("index_" + s.category, 0))
        for n, (name, obj, mat, key) in enumerate(rows):
            item = s.items.add()
            item.name, item.obj, item.material, item.key, item.kind = name, obj, mat, key, s.category
            item.selected = identity(obj, mat, key) in checked
            if identity(obj, mat, key) == old_identity:
                index = n
        s.index = min(max(index, 0), len(s.items) - 1) if s.items else -1
        if s.items and (not same_scope or was_empty):
            s.items[s.index].selected = True
        if any(i.selected for i in s.items) and not s.items[s.index].selected:
            s.index = next(n for n, item in enumerate(s.items) if item.selected)
        s['_root'] = root_stamp
        if not same_scope:
            s.filter_text = ''
            s.batch_message = ''
            s['_anchor'] = s.index
        s["_category"] = s.category
        if s.category == 'COLLECTION':
            arm = armature_of(s.root, context.scene)
            active_collection = arm.data.collections.active if arm else None
            if active_collection and old_identity and old_identity not in [identity(i.obj, i.material, i.key) for i in s.items]:
                for n, item in enumerate(s.items):
                    if item.key == active_collection.name:
                        s.index = n
                        item.selected = True
    finally:
        _refreshing = False


def _changed(self, context):
    if hasattr(context.scene,'clm_pe_morph'):morph_editor.scope_changed(context)
    refresh(context)
    _remember_native_selection(context, self)


def _index_changed(self, context):
    if not _refreshing:
        if hasattr(context.scene,'clm_pe_morph'):morph_editor.scope_changed(context)
        self["index_" + self.category] = self.index
        if not _selection_edit:
            for n, item in enumerate(self.items):
                item.selected = n == self.index
            self['_anchor'] = self.index
            self.batch_message = ''
            sync_view_selection(context, self)


def _size_get(item, axis):
    obj = item.obj
    if not obj or not hasattr(obj, 'mmd_rigid'):
        return 0.0
    index=(0,2,1)[axis] if obj.mmd_rigid.shape=='BOX' else axis
    return obj.mmd_rigid.size[index]*physics_size_factor(obj)


def physics_export_scale():
    wm=bpy.context.window_manager
    return float(wm.aotu_pe_scale) if hasattr(wm,'aotu_pe_scale') else bpy.context.scene.clm_mmd_workspace.pmx_export_scale


def _physics_export_scale_get(settings):
    wm=bpy.context.window_manager
    return float(wm.aotu_pe_scale) if hasattr(wm,'aotu_pe_scale') else settings.get('pmx_export_scale',12.5)


def _physics_export_scale_set(settings,value):
    wm=bpy.context.window_manager
    if hasattr(wm,'aotu_pe_scale'):wm.aotu_pe_scale=value
    else:settings['pmx_export_scale']=value


def physics_size_factor(obj):
    # Match mmd_tools PMXExporter; BOX xzy permutation is handled by callers.
    return physics_export_scale()*sum(obj.matrix_world.to_scale())/3.


def _size_set(item, axis, value):
    obj = item.obj
    if not obj or obj.mode != 'OBJECT':
        return
    root = root_of(obj)
    if root and root.mmd_root.is_built:
        return
    size = list(obj.mmd_rigid.size)
    factor=physics_size_factor(obj)
    if not math.isfinite(factor) or factor<=1e-12:return
    index=(0,2,1)[axis] if obj.mmd_rigid.shape=='BOX' else axis
    size[index] = max(value, .0001)/factor
    obj.mmd_rigid.size = size


def _physics_alignment_target(obj,arm,root,anchor):
    def bone_for(body):
        if body and body.mmd_type=='RIGID_BODY' and root_of(body)==root:
            return arm.data.bones.get(body.mmd_rigid.bone)
        return None
    if obj.mmd_type=='RIGID_BODY':
        bone=bone_for(obj)
        if bone is None:raise ValueError('未关联有效骨骼')
        local=bone.head_local if anchor=='HEAD' else bone.tail_local if anchor=='TAIL' else (bone.head_local+bone.tail_local)*.5
        return bone,arm.matrix_world@local
    constraint=obj.rigid_body_constraint
    if not constraint or not constraint.object1 or not constraint.object2:raise ValueError('J 点缺少连接刚体')
    if any(root_of(body)!=root for body in (constraint.object1,constraint.object2)):raise ValueError('J 点连接了其他模型')
    a,b=bone_for(constraint.object1),bone_for(constraint.object2)
    if a is None and b is None:raise ValueError('连接刚体没有关联骨骼')
    if a is None:return b,arm.matrix_world@b.head_local
    if b is None:return a,arm.matrix_world@a.head_local
    if a==b:return a,arm.matrix_world@a.head_local
    if a in b.parent_recursive:return b,arm.matrix_world@b.head_local
    if b in a.parent_recursive:return a,arm.matrix_world@a.head_local
    return b,arm.matrix_world@((a.head_local+b.head_local)*.5)


def _physics_alignment_rotation(arm,bone,position,orientation,center):
    z=arm.matrix_world.to_3x3()@(bone.tail_local-bone.head_local)
    if z.length<1e-8:raise ValueError('关联骨骼长度为零')
    z.normalize()
    reference=arm.matrix_world.to_3x3()@(-bone.matrix_local.to_3x3().col[2])
    if orientation=='RADIAL':
        axis=arm.matrix_world.to_quaternion()@Vector((0,0,1))
        radial=position-center;radial-=axis*radial.dot(axis)
        if radial.length>1e-8:reference=radial
    y=reference-z*reference.dot(z)
    if y.length<1e-8:
        reference=min((Vector((1,0,0)),Vector((0,1,0)),Vector((0,0,1))),key=lambda v:abs(v.dot(z)))
        y=reference-z*reference.dot(z)
    y.normalize();x=y.cross(z).normalized();y=z.cross(x).normalized()
    return Matrix((x,y,z)).transposed().to_quaternion()


class CLM_MMD_OT_AlignPhysicsBone(bpy.types.Operator):
    bl_idname='clm_mmd.align_physics_to_bone'
    bl_label='对齐骨骼位置与朝向'
    bl_description='对齐勾选刚体或 J 点；裙筒环向会逐个计算各自朝外的局部轴'
    bl_options={'REGISTER','UNDO'}
    orientation:EnumProperty(items=[('BONE','沿骨骼','跟随骨骼方向与局部轴'),('RADIAL','裙筒环向','Z 沿骨骼、Y 沿裙筒径向向外')],default='BONE')

    def execute(self,context):
        s=context.scene.clm_mmd_workspace
        try:
            if s.category not in {'RIGID','JOINT'} or not s.root:raise ValueError('请先勾选刚体或 J 点')
            if s.root.mmd_root.is_built:raise ValueError('请先清理物理构建再对齐')
            arm=armature_of(s.root,context.scene)
            if not arm:raise ValueError('当前模型没有骨架')
            if arm.mode=='EDIT':raise ValueError('请先退出骨骼编辑模式再对齐')
            center=s.physics_ring_center.matrix_world.translation if s.physics_ring_center else arm.matrix_world.translation
            plans=[];skipped=[]
            for item in checked_items(s):
                obj=item.obj
                try:
                    if not obj.is_editable:raise ValueError('对象为只读')
                    bone,position=_physics_alignment_target(obj,arm,s.root,s.physics_rigid_anchor)
                    rotation=_physics_alignment_rotation(arm,bone,position,self.orientation,center)
                    inverse=obj.matrix_parent_inverse.copy()
                    replacement=inverse.copy()
                    if obj.parent:
                        effective_parent=obj.matrix_world@obj.matrix_basis.inverted_safe()
                        columns=[effective_parent.to_3x3().col[i] for i in range(3)]
                        lengths=[v.length for v in columns]
                        sheared=any(abs(columns[i].normalized().dot(columns[j].normalized()))>1e-6 for i,j in ((0,1),(0,2),(1,2)))
                        if max(lengths)-min(lengths)>1e-6 or sheared:
                            if abs(effective_parent.determinant())<1e-12:raise ValueError('父级变换不可逆，不能安全对齐')
                            # Cancel the existing anisotropic parent frame at the
                            # binding instant. Parenting remains intact and future
                            # parent motion still applies as a relative transform.
                            replacement=inverse@effective_parent.inverted()
                    plans.append((obj,obj.matrix_world.copy(),inverse,replacement,Matrix.LocRotScale(position,rotation,obj.matrix_world.to_scale())))
                except ValueError as exc:skipped.append(obj.name+'：'+str(exc))
            if not plans:raise ValueError(skipped[0] if skipped else '请先勾选要对齐的条目')
            try:
                for obj,old,inverse,replacement,new in plans:
                    obj.matrix_parent_inverse=replacement
                    obj.matrix_world=new
                context.view_layer.update()
            except Exception:
                for obj,old,inverse,replacement,new in plans:
                    obj.matrix_parent_inverse=inverse;obj.matrix_world=old
                raise
            message='已对齐 '+str(len(plans))+' 项'+('；跳过 '+str(len(skipped))+' 项：'+skipped[0] if skipped else '')
            s.batch_message=message;self.report({'WARNING'} if skipped else {'INFO'},message)
            return {'FINISHED'}
        except (ValueError,RuntimeError) as exc:
            self.report({'ERROR'},str(exc));return {'CANCELLED'}


def _root_poll(self, obj):
    return getattr(obj, 'mmd_type', '') == 'ROOT'


def _edit_rest_bone(item, context, change):
    arm = item.obj
    if not arm or arm.type != 'ARMATURE' or item.key not in arm.data.bones:
        return False
    if any(getattr(data, 'library', None) for data in (arm, arm.data)):
        return False
    active = context.view_layer.objects.active
    mode = active.mode if active else 'OBJECT'
    selection = [(o, o.select_get()) for o in context.view_layer.objects]
    bones = {b.name: getattr(b if hasattr(b, 'select') else arm.pose.bones[b.name], 'select', False) for b in arm.data.bones}
    active_bone = arm.data.bones.active.name if arm.data.bones.active else None
    already_edit = arm.mode == 'EDIT'
    try:
        if not already_edit:
            if active and mode != 'OBJECT':
                bpy.ops.object.mode_set(mode='OBJECT')
            for obj, _ in selection:
                obj.select_set(obj == arm)
            context.view_layer.objects.active = arm
            bpy.ops.object.mode_set(mode='EDIT')
        change(arm.data.edit_bones[item.key], arm.data.edit_bones)
        return True
    finally:
        if not already_edit:
            if arm.mode == 'EDIT':
                bpy.ops.object.mode_set(mode='OBJECT')
            for name, state in bones.items():
                b = arm.data.bones.get(name)
                if b:
                    target = b if hasattr(b, 'select') else arm.pose.bones[name]
                    target.select = state
            arm.data.bones.active = arm.data.bones.get(active_bone) if active_bone else None
            for obj, selected in selection:
                obj.select_set(selected)
            context.view_layer.objects.active = active
            if active and mode != 'OBJECT':
                bpy.ops.object.mode_set(mode=mode)


def set_bone_parent(item, name, context):
    arm = item.obj
    if not arm:
        return False
    bones = arm.data.edit_bones if arm.mode == 'EDIT' else arm.data.bones
    if item.key not in bones or (name and name not in bones):
        return False
    parent = bones.get(name)
    while parent:
        if parent.name == item.key:
            return False
        parent = parent.parent
    def change(bone, bones):
        matrix, length = bone.matrix.copy(), bone.length
        bone.use_connect = False
        bone.parent = bones.get(name)
        bone.matrix, bone.length = matrix, length
    return _edit_rest_bone(item, context, change)


def _parent_get(item):
    bone = item.obj.data.edit_bones.get(item.key) if item.obj and item.obj.mode == 'EDIT' else item_target(item)
    return bone.parent.name if bone and bone.parent else ''


def _parent_set(item, value):
    if not set_bone_parent(item, value, bpy.context):
        item.id_data.clm_mmd_workspace.batch_message = '父骨骼无效、循环引用或数据只读'


def _tail_get(item):
    bone = item_target(item)
    return tuple(bone.bone.tail_local - bone.bone.head_local) if bone else (0, 0, 0)


def _tail_set(item, value):
    from mathutils import Vector
    def change(bone, bones):
        bone.use_connect = False
        bone.tail = bone.head + Vector(value)
    _edit_rest_bone(item, bpy.context, change)


def _bone_flag_get(item, key):
    bone = item_target(item)
    if not bone:
        return False
    return not all(getattr(bone, key))


def _bone_flag_set(item, key, value):
    bone = item_target(item)
    if bone and not item.obj.library and not item.obj.data.library:
        setattr(bone, key, (not value,) * 3)


def _bone_visible_get(item):
    bone = item_target(item)
    if not bone:
        return False
    prefix = bone.mmd_bone.__class__.__module__.split('.properties.')[0]
    return importlib.import_module(prefix + '.core.bone').FnBone.is_visible_in_viewport(bone)


def _bone_visible_set(item, value):
    bone = item_target(item)
    if bone and not item.obj.library and not item.obj.data.library:
        target = bone if bpy.app.version >= (5, 0, 0) else bone.bone
        target.hide = not value


def _ik_matches(item):
    return [(pb, c) for pb in item.obj.pose.bones for c in pb.constraints
            if c.type == 'IK' and (pb.name == item.key or (c.target == item.obj and c.subtarget == item.key))]


def _ik_chain(owner, constraint):
    start = owner if constraint.use_tail else owner.parent
    links = ([start] + list(start.parent_recursive)) if start else []
    return links[:constraint.chain_count] if constraint.chain_count else links


class CLM_MMD_OT_SelectIKLink(bpy.types.Operator):
    bl_idname = 'clm_mmd.select_ik_link'
    bl_label = '选择 IK 链接编辑角度限制'
    bl_description = '仅切换 IK 角度限制编辑项，保持列表和视图骨骼选择'
    index: IntProperty(min=0)
    owner: StringProperty()
    constraint: StringProperty()

    def execute(self, context):
        item = current_item(context.scene.clm_mmd_workspace)
        if not item or item.kind != 'BONE':
            return {'CANCELLED'}
        match = next(((bone, c) for bone, c in _ik_matches(item)
                      if bone.name == self.owner and c.name == self.constraint), None)
        if not match or self.index >= len(_ik_chain(*match)):
            return {'CANCELLED'}
        item.ik_link_index = self.index
        return {'FINISHED'}


def _ik_get(item):
    return any(not c.mute for _, c in _ik_matches(item)) if item.obj else False


def _ik_set(item, value):
    if item.obj and not item.obj.library and not item.obj.data.library:
        for _, constraint in _ik_matches(item):
            constraint.mute = not value


def _ignore_samegroup_get(item):
    rigid = item.obj.mmd_rigid if item.obj else None
    return bool(rigid and rigid.collision_group_mask[rigid.collision_group_number])


def _ignore_samegroup_set(item, value):
    if item.obj and not item.obj.library:
        rigid = item.obj.mmd_rigid
        mask = list(rigid.collision_group_mask)
        mask[rigid.collision_group_number] = value
        rigid.collision_group_mask = mask


def material_fn(material):
    prefix = material.mmd_material.__class__.__module__.split('.properties.')[0]
    return importlib.import_module(prefix + '.core.material').FnMaterial(material)


def assign_material_texture(material, kind, filepath, obj=None):
    if not material or material.library or (material.node_tree and material.node_tree.library):
        raise ValueError('材质只读')
    filepath = bpy.path.abspath(filepath)
    if not os.path.isfile(filepath):
        raise ValueError('纹理文件不存在')
    fn = material_fn(material)
    if kind == 'TEX':
        fn.create_texture(filepath)
    elif kind == 'SPA':
        fn.create_sphere_texture(filepath, obj)
    elif kind == 'TOON':
        material.mmd_material.is_shared_toon_texture = False
        material.mmd_material.toon_texture = filepath
        fn.create_toon_texture(filepath)
    else:
        raise ValueError('未知纹理类型')


class CLM_MMD_OT_AddTexture(bpy.types.Operator, ImportHelper):
    bl_idname = 'clm_mmd.add_texture'
    bl_label = '添加材质纹理'
    bl_options = {'UNDO'}
    material_uid: IntProperty(options={'SKIP_SAVE'})
    object_uid: IntProperty(options={'SKIP_SAVE'})
    kind: EnumProperty(items=[('TEX', 'Tex', ''), ('SPA', 'Spa', ''), ('TOON', 'Toon', '')])
    filter_glob: StringProperty(default='*.png;*.jpg;*.jpeg;*.bmp;*.tga;*.dds;*.tif;*.tiff;*.sph;*.spa', options={'HIDDEN'})

    def execute(self, context):
        try:
            material = next((m for m in bpy.data.materials if m.session_uid == self.material_uid), None)
            obj = next((o for o in bpy.data.objects if o.session_uid == self.object_uid), None)
            assign_material_texture(material, self.kind, self.filepath, obj)
        except (ValueError, RuntimeError, OSError) as exc:
            self.report({'ERROR'}, str(exc))
            return {'CANCELLED'}
        return {'FINISHED'}



_MATERIAL_PREVIEW = '_clm_material_face_preview'
_material_export_guards = []


def _item_visible_get(item):
    settings = item.id_data.clm_mmd_workspace
    return display_state(item, settings, bpy.context)[0] if item_target(item) else False


def _item_visible_set(item, value):
    settings = item.id_data.clm_mmd_workspace
    try:
        set_item_visible(bpy.context, settings, item, bool(value))
    except (RuntimeError, AttributeError, ValueError) as exc:
        settings.batch_message = str(exc)


def _material_hidden(group, material):
    if group and group.solos:
        return not any(x.material == material for x in group.solos)
    return bool(group and any(x.material == material and x.hidden for x in group.members if x.kind == 'MATERIAL'))


def _preview_modifier(obj):
    return next((m for m in obj.modifiers if m.type == 'NODES' and m.node_group
                 and m.node_group.get(_MATERIAL_PREVIEW)), None)


def _remove_material_preview(obj):
    for modifier in list(obj.modifiers):
        if modifier.type != 'NODES' or not modifier.node_group or not modifier.node_group.get(_MATERIAL_PREVIEW):
            continue
        tree = modifier.node_group
        obj.modifiers.remove(modifier)
        if tree.users == 0:bpy.data.node_groups.remove(tree)


def _material_preview(obj, materials):
    modifier = _preview_modifier(obj)
    if not materials:
        if modifier:_remove_material_preview(obj)
        return
    if obj.library or obj.data.library:
        raise ValueError('材质面显示需要可编辑的网格')
    signature = '|'.join(str(mat.session_uid) for mat in materials)
    if modifier and modifier.node_group.get('materials') == signature:
        return
    if not modifier:
        tree = bpy.data.node_groups.new('草履虫 · 材质面视图', 'GeometryNodeTree')
        tree[_MATERIAL_PREVIEW] = True
        tree.interface.new_socket(name='Geometry', in_out='INPUT', socket_type='NodeSocketGeometry')
        tree.interface.new_socket(name='Geometry', in_out='OUTPUT', socket_type='NodeSocketGeometry')
        modifier = obj.modifiers.new('草履虫 · 材质面视图', 'NODES')
        modifier.node_group = tree
        modifier.show_render = False
        modifier.show_in_editmode = False
        modifier.show_expanded = False
    tree = modifier.node_group
    if tree.users > 1:
        tree = tree.copy();modifier.node_group = tree
    tree.nodes.clear()
    inputs = tree.nodes.new('NodeGroupInput')
    outputs = tree.nodes.new('NodeGroupOutput')
    delete = tree.nodes.new('GeometryNodeDeleteGeometry');delete.domain = 'FACE';delete.mode = 'ALL'
    tree.links.new(inputs.outputs['Geometry'], delete.inputs['Geometry'])
    selection = None
    for material in materials:
        node = tree.nodes.new('GeometryNodeMaterialSelection');node.inputs['Material'].default_value = material
        if selection is None:selection = node.outputs['Selection']
        else:
            combine = tree.nodes.new('FunctionNodeBooleanMath');combine.operation = 'OR'
            tree.links.new(selection, combine.inputs[0]);tree.links.new(node.outputs['Selection'], combine.inputs[1])
            selection = combine.outputs[0]
    tree.links.new(selection, delete.inputs['Selection'])
    tree.links.new(delete.outputs['Geometry'], outputs.inputs['Geometry'])
    tree['materials'] = signature


# Ownership follows BMesh custom data through topology edits and mode changes.
# Never restore by element index: deletion and undo can reuse those indices.
_MATERIAL_EDIT_LAYERS = (('.clm_material_hide_point', 'verts', 'vertices'),
                         ('.clm_material_hide_edge', 'edges', 'edges'),
                         ('.clm_material_hide_face', 'faces', 'polygons'))
_material_edit_meshes = set()


def _has_material_edit_ownership(mesh):
    return mesh.session_uid in _material_edit_meshes or any(mesh.attributes.get(name) is not None for name, _, _ in _MATERIAL_EDIT_LAYERS)


def _restore_material_edit(mesh):
    changed = False
    if mesh.is_editmode:
        bm = bmesh.from_edit_mesh(mesh)
        for name, domain, _ in _MATERIAL_EDIT_LAYERS:
            elements = getattr(bm, domain)
            layer = elements.layers.int.get(name)
            if layer is None:continue
            for element in elements:
                if element[layer]:element.hide = False
            elements.layers.int.remove(layer)
            changed = True
        if changed:bmesh.update_edit_mesh(mesh, loop_triangles=False, destructive=False)
    else:
        # BMesh int layers become mesh attributes on leaving Edit Mode. Restore
        # directly through RNA, avoiding mesh reconstruction and shape-key writes.
        for name, _, domain in _MATERIAL_EDIT_LAYERS:
            attribute = mesh.attributes.get(name)
            if attribute is None:continue
            for element, owner in zip(getattr(mesh, domain), attribute.data):
                if owner.value:element.hide = False
            mesh.attributes.remove(attribute)
            changed = True
        if changed:mesh.update()
    _material_edit_meshes.discard(mesh.session_uid)


def _material_edit_preview(obj, materials):
    mesh = obj.data
    if not mesh.is_editmode:
        if _has_material_edit_ownership(mesh):_restore_material_edit(mesh)
        return
    bm = bmesh.from_edit_mesh(mesh)
    hidden_slots = {n for n, slot in enumerate(obj.material_slots) if slot.material in materials}
    changed = False
    owned = False
    for name, domain, _ in _MATERIAL_EDIT_LAYERS:
        def targeted(element):
            if domain == 'faces':return element.material_index in hidden_slots
            return bool(element.link_faces) and all(f.material_index in hidden_slots for f in element.link_faces)
        elements = getattr(bm, domain)
        layer = elements.layers.int.get(name)
        if layer is None and not any(targeted(e) and not e.hide for e in elements):continue
        if layer is None:layer = elements.layers.int.new(name);changed = True
        domain_owned = False
        for element in elements:
            if targeted(element):
                if not element.hide:
                    element[layer] = 1
                    element.hide = True
                    changed = True
                if element.select:
                    # Blender ignores deselection writes while hide is true.
                    element.hide = False
                    element.select = False
                    element.hide = True
                    changed = True
            elif element[layer]:
                element.hide = False
                element[layer] = 0
                changed = True
            domain_owned = domain_owned or bool(element[layer])
        if not domain_owned:elements.layers.int.remove(layer);changed = True
        owned = owned or domain_owned
    if owned:_material_edit_meshes.add(mesh.session_uid)
    else:_material_edit_meshes.discard(mesh.session_uid)
    if changed:bmesh.update_edit_mesh(mesh, loop_triangles=False, destructive=False)


def _sync_material_edit_cleanup(active_meshes=()):
    active_meshes = set(active_meshes)
    for mesh in bpy.data.meshes:
        if mesh.session_uid not in active_meshes and _has_material_edit_ownership(mesh):
            _restore_material_edit(mesh)
    _material_edit_meshes.intersection_update(mesh.session_uid for mesh in bpy.data.meshes)


def sync_material_preview(context, settings):
    # Face filtering is model scoped and leaves object visibility untouched.
    group = next((g for g in settings.display_groups if g.root == settings.root and g.category == 'MATERIAL'), None)
    if group:
        legacy = [n for n, member in enumerate(group.members) if member.kind == 'OBJECT']
        if legacy:
            layer = _group_layer(context.scene, group) or context.view_layer
            with context.temp_override(view_layer=layer):
                for n in legacy:
                    member = group.members[n]
                    if member.obj:_set_hidden(member.obj, '', 'OBJECT', member.hidden, bpy.context, member.disabled)
            for n in reversed(legacy):group.members.remove(n)
            group.view_layer = '';group.layer_token = ''
    hidden = {row[2] for row in _rows(settings.root, context.scene, 'MATERIAL') if _material_hidden(group, row[2])}
    active_edit_meshes = set()
    for obj in model_objects(settings.root, context.scene):
        if obj.type == 'MESH' and getattr(obj, 'mmd_type', 'NONE') == 'NONE':
            relevant = sorted((mat for mat in hidden if any(slot.material == mat for slot in obj.material_slots)), key=lambda mat:mat.session_uid)
            _material_preview(obj, relevant)
            # A shared edit mesh has one hide state. Leave it alone when another
            # model or object-linked material mapping would make that ambiguous.
            owners = [o for o in bpy.data.objects if o.type == 'MESH' and o.data == obj.data]
            if all(root_of(o) == settings.root and tuple(s.material for s in o.material_slots) == tuple(s.material for s in obj.material_slots) for o in owners):
                _material_edit_preview(obj, relevant)
                if obj.data.is_editmode:active_edit_meshes.add(obj.data.session_uid)
    _sync_material_edit_cleanup(active_edit_meshes)
    if hidden:_install_material_export_guards()


def _install_material_export_guards():
    # MMD Tools evaluates viewport modifiers during PMX export. Pause only our
    # face preview around that export and restore it even when writing fails.
    import sys, functools
    for module in list(sys.modules.values()):
        if not module or not getattr(module, '__name__', '').endswith('mmd_tools.core.pmx.exporter'):
            continue
        if any(existing == module for existing, _, _ in _material_export_guards):continue
        original = getattr(module, 'export', None)
        if not callable(original):continue
        def guard(original):
            @functools.wraps(original)
            def export(*args, **kwargs):
                paused = [(modifier, modifier.show_viewport) for obj in bpy.data.objects
                          for modifier in obj.modifiers if modifier.type == 'NODES' and modifier.node_group
                          and modifier.node_group.get(_MATERIAL_PREVIEW)]
                for modifier, _ in paused:modifier.show_viewport = False
                if paused:bpy.context.view_layer.update()
                try:return original(*args, **kwargs)
                finally:
                    for modifier, visible in paused:modifier.show_viewport = visible
                    if paused:bpy.context.view_layer.update()
            return export
        wrapped = guard(original);module.export = wrapped
        _material_export_guards.append((module, original, wrapped))


def set_item_visible(context, settings, item, visible):
    if item_target(item) is None or root_of(item.obj) != settings.root:return
    if item.kind == 'COLLECTION':
        target = item_target(item)
        if not item.obj.data.collections.is_solo_active:target.is_visible = visible
    elif item.kind == 'MATERIAL':
        group = _display_group(settings, context, create=True)
        if group.solos:return
        member = next((x for x in group.members if x.kind == 'MATERIAL' and x.material == item.material), None)
        if not member:
            member = group.members.add();member.kind = 'MATERIAL';member.material = item.material
        member.hidden = not visible
        sync_material_preview(context, settings)
    else:
        group = _display_group(settings, context)
        if group and group.solos:return
        for source in _display_sources(item, settings, context):_set_hidden(*source, not visible, context)
    _remember_native_selection(context, settings)
    if context.screen:
        for area in context.screen.areas:area.tag_redraw()


def _morph_identity(item):
    if item.key.startswith('@'):return item.key[1:].split('|',1)
    return 'vertex_morphs',item.key

def _morph_category(item):
    root=root_of(item.obj)
    if not root:return 'OTHER'
    kind,name=_morph_identity(item);meta=morph_api.metadata(root,kind,name)
    if meta:return meta.category
    saved=morph_api.shape_category(item.obj,name)
    return saved['category'] if saved else morph_api.guess_category(name)

def _morph_name_get(item):
    kind,name=_morph_identity(item);return name

def _morph_name_set(item,value):
    root=root_of(item.obj)
    if not root or not root.is_editable:return
    kind,old=_morph_identity(item)
    meta=morph_api.metadata(root,kind,old)
    category=_morph_category(item)
    if meta is None:
        meta=morph_api.metadata(root,kind,old,True);meta.category=category;meta['clm_category_source']='MANUAL'
    # MMD Tools' native setter renames keys in every mesh and updates references.
    meta.name=value;new=meta.name
    if kind=='vertex_morphs':
        for obj in morph_api.meshes(root):
            saved=morph_api.shape_category(obj,old)
            if saved:
                values={k:dict(v) for k,v in obj.data.get('clm_morph_categories',{}).items()}
                values.pop(old,None);values[new]=saved;obj.data['clm_morph_categories']=values
    item.key=('@'+kind+'|'+new) if kind!='vertex_morphs' else new
    item.name=new

def _morph_set_category(item,value):
    root=root_of(item.obj)
    if not root:return
    kind,name=_morph_identity(item);morph_api.assign_category(root,kind,[name],morph_api.CATEGORIES[value][0])

class CLM_MMD_Item(bpy.types.PropertyGroup):
    obj: PointerProperty(type=bpy.types.Object)
    material: PointerProperty(type=bpy.types.Material)
    key: StringProperty()
    kind: StringProperty()
    selected: BoolProperty(name="选择用于批量修改", default=False)
    visible: BoolProperty(name="视图可见", description="按住并拖过眼睛可批量切换；材质只显示或隐藏使用它的面", get=_item_visible_get, set=_item_visible_set)
    morph_name:StringProperty(name='名称',get=_morph_name_get,set=_morph_name_set)
    morph_category: EnumProperty(name='表情分类',items=morph_api.CATEGORIES,get=lambda i:next(n for n,c in enumerate(morph_api.CATEGORIES) if c[0]==_morph_category(i)),set=_morph_set_category)
    display_token: StringProperty()
    ignore_samegroup: BoolProperty(name='忽略同组碰撞', get=_ignore_samegroup_get, set=_ignore_samegroup_set)
    shared_toon: EnumProperty(name='内置 Toon', items=[(str(i), 'toon' + str(i + 1), '', i) for i in range(10)], get=lambda i: i.material.mmd_material.shared_toon_texture if i.material else 0, set=lambda i, v: setattr(i.material.mmd_material, 'shared_toon_texture', v) if i.material and not i.material.library else None)
    parent_bone: StringProperty(name='亲骨骼', get=_parent_get, set=_parent_set)
    tail_offset: FloatVectorProperty(name='相对', size=3, subtype='XYZ', get=_tail_get, set=_tail_set)
    bone_rotate: BoolProperty(name='旋转', get=lambda i: _bone_flag_get(i, 'lock_rotation'), set=lambda i, v: _bone_flag_set(i, 'lock_rotation', v))
    bone_move: BoolProperty(name='移动', get=lambda i: _bone_flag_get(i, 'lock_location'), set=lambda i, v: _bone_flag_set(i, 'lock_location', v))
    bone_visible: BoolProperty(name='显示', get=_bone_visible_get, set=_bone_visible_set)
    ik_link_index: IntProperty(name='IK Link', min=0, default=0, options={'SKIP_SAVE'})
    bone_ik: BoolProperty(name='IK', get=_ik_get, set=_ik_set)
    size_x: FloatProperty(name="X", min=.0001,precision=6, get=lambda s: _size_get(s, 0), set=lambda s, v: _size_set(s, 0, v))
    size_y: FloatProperty(name="Y", min=.0001,precision=6, get=lambda s: _size_get(s, 1), set=lambda s, v: _size_set(s, 1, v))
    size_z: FloatProperty(name="Z", min=.0001,precision=6, get=lambda s: _size_get(s, 2), set=lambda s, v: _size_set(s, 2, v))
    group: IntProperty(name="碰撞组", min=1, max=16,
        get=lambda s: s.obj.mmd_rigid.collision_group_number + 1 if s.obj else 1,
        set=lambda s, v: setattr(s.obj.mmd_rigid, 'collision_group_number', v - 1) if s.obj else None)


# Batch properties use real data through getters/setters. They never copy a whole
# material/rigid body, and never listen to unrelated native Properties changes.
_selection_edit = False
_BATCH_FIELDS = {}


def checked_items(settings):
    scene = settings.id_data
    return [item for item in settings.items if item.selected and item.kind == settings.category
            and item.obj and item.obj.name in scene.objects and root_of(item.obj) == settings.root
            and item_target(item) is not None]


def visible_indices(settings):
    query = settings.filter_text.casefold().strip()
    def matches(item):
        if query and query not in item.name.casefold():return False
        if settings.category!='MORPH':return True
        if settings.morph_filter!='ALL' and _morph_category(item)!=settings.morph_filter:return False
        if not settings.morph_show_originals and settings.morph_filter!='SYSTEM':
            kind,name=_morph_identity(item)
            meta=morph_api.metadata(settings.root,kind,name) if settings.root else None
            if meta and meta.get('clm_attach_original'):return False
        return True
    return [n for n,item in enumerate(settings.items) if matches(item)]


def select_item(settings, index, toggle=False, range_select=False, extend=False):
    global _selection_edit
    if not 0 <= index < len(settings.items):
        return
    _selection_edit = True
    try:
        visible = visible_indices(settings)
        if range_select:
            anchor = settings.get('_anchor', settings.index)
            if anchor not in visible:
                anchor = index
            if index not in visible:
                return
            lo, hi = sorted((visible.index(anchor), visible.index(index)))
            if not extend:
                for item in settings.items:
                    item.selected = False
            for n in visible[lo:hi + 1]:
                settings.items[n].selected = True
        elif toggle:
            settings.items[index].selected = not settings.items[index].selected
            settings['_anchor'] = index
        else:
            for n, item in enumerate(settings.items):
                item.selected = n == index
            settings['_anchor'] = index
        settings.index = index if settings.items[index].selected else next(
            (n for n, item in enumerate(settings.items) if item.selected), index)
        settings.batch_message = ''
    finally:
        _selection_edit = False


class CLM_MMD_OT_SelectItem(bpy.types.Operator):
    bl_idname = 'clm_mmd.select_item'
    bl_label = '选择列表条目'
    bl_description = '单击单选；Ctrl 增减；Shift 连选，并同步选择 3D 视图中的对应内容'
    bl_options = {'UNDO'}
    index: IntProperty()
    toggle: BoolProperty(default=False)
    extend: BoolProperty(default=False)
    range_select: BoolProperty(default=False)

    def invoke(self, context, event):
        # UI buttons may reuse last operator properties; always read this click.
        self.toggle = event.ctrl or event.oskey
        self.range_select = event.shift
        self.extend = event.ctrl or event.oskey
        return self.execute(context)

    def execute(self, context):
        select_item(context.scene.clm_mmd_workspace, self.index, self.toggle, self.range_select, self.extend)
        sync_view_selection(context, context.scene.clm_mmd_workspace)
        return {'FINISHED'}


class CLM_MMD_OT_SelectAll(bpy.types.Operator):
    bl_idname = 'clm_mmd.select_all'
    bl_label = '选择列表'
    action: EnumProperty(items=[('ALL', '全选筛选结果', ''), ('NONE', '清空选择', '')])

    def execute(self, context):
        global _selection_edit
        s = context.scene.clm_mmd_workspace
        visible = set(visible_indices(s))
        _selection_edit = True
        try:
            for n, item in enumerate(s.items):
                item.selected = self.action == 'ALL' and n in visible
            selected = [n for n, item in enumerate(s.items) if item.selected]
            if selected:
                s.index = selected[0]
                s['_anchor'] = s.index
            s.batch_message = ''
        finally:
            _selection_edit = False
        sync_view_selection(context, s)
        return {'FINISHED'}


def _batch_source(item, route):
    if not item:
        return None
    if route == 'item':
        return item
    if route == 'object':
        return item.obj
    if route == 'data':
        return item_target(item)
    if route == 'physics':
        return item.obj.rigid_body if item.obj else None
    if route == 'constraint':
        return item.obj.rigid_body_constraint if item.obj else None
    if route == 'mmd':
        if item.kind == 'MATERIAL':
            return getattr(item.material, 'mmd_material', None)
        if item.kind == 'BONE':
            return getattr(item_target(item), 'mmd_bone', None)
        return getattr(item.obj, 'mmd_rigid' if item.kind == 'RIGID' else 'mmd_joint', None)
    return None


def _batch_members(item,spec):
    if item.kind=='MORPH' and not item.key.startswith('@') and spec['route']=='data':
        return [SimpleNamespace(kind='MORPH',obj=obj,key=item.key)
                for obj in morph_meshes(root_of(item.obj),item.key)]
    return [item]


def _field_value(item, spec):
    source = _batch_source(item, spec['route'])
    if source is None or not hasattr(source, spec['key']):
        return spec['default']
    value = getattr(source, spec['key'])
    return value[spec['component']] if spec['component'] is not None else value


def _comparable(value):
    return tuple(value) if not isinstance(value, (str, float, int, bool)) else value


def batch_mixed(settings, field):
    spec = _BATCH_FIELDS[field]
    values = [_comparable(_field_value(member, spec)) for item in checked_items(settings) for member in _batch_members(item,spec)]
    return bool(values and any(value != values[0] for value in values[1:]))


def _batch_get(proxy, field):
    spec = _BATCH_FIELDS[field]
    item = current_item(proxy.id_data.clm_mmd_workspace)
    value = _field_value(item, spec) if item else spec['default']
    if spec['enum']:
        return next((n for n, entry in enumerate(spec['enum']) if entry[0] == value), 0)
    return value


def _batch_set(proxy, field, value):
    settings = proxy.id_data.clm_mmd_workspace
    spec = _BATCH_FIELDS[field]
    if settings.category not in spec['categories']:
        return
    if spec['enum']:
        value = spec['enum'][value][0]
    items = [member for item in checked_items(settings) for member in _batch_members(item,spec)]
    if settings.category in {'RIGID', 'JOINT'} and settings.root and settings.root.mmd_root.is_built:
        settings.batch_message = '请先清理物理构建，再批量修改'
        return
    current = current_item(settings)
    shape = current.obj.mmd_rigid.shape if current and current.kind == 'RIGID' else None
    changes, seen, skipped = [], set(), 0
    for item in items:
        source = _batch_source(item, spec['route'])
        if source is None or not hasattr(source, spec['key']):
            skipped += 1
            continue
        if item.kind == 'RIGID':
            if spec['key'] in {'mass', 'linear_damping', 'angular_damping'} and item.obj.mmd_rigid.type == '0':
                skipped += 1
                continue
            if spec['key'].startswith('size_') and (item.obj.mmd_rigid.shape != shape or item.obj.mode != 'OBJECT'):
                skipped += 1
                continue
            if spec['key'] == 'shape' and item.obj.mode != 'OBJECT':
                skipped += 1
                continue
        if item.kind == 'MORPH' and getattr(item.obj.data,'shape_keys',None) and item_target(item) == item.obj.data.shape_keys.reference_key:
            skipped += 1
            continue
        if item.obj.library and not item.obj.override_library:
            skipped += 1
            continue
        owner = source.id_data
        if source.is_property_readonly(spec['key']) or (getattr(owner, 'library', None) and not getattr(owner, 'override_library', None)):
            skipped += 1
            continue
        identity = (source.as_pointer(), spec['key'])
        if identity in seen:
            continue
        seen.add(identity)
        old = _comparable(getattr(source, spec['key']))
        new = value
        if spec['component'] is not None:
            new = list(old)
            new[spec['component']] = value
        changes.append((source, old, new))
    applied = []
    try:
        for source, old, new in changes:
            applied.append((source, old))
            setattr(source, spec['key'], new)
    except (ValueError, TypeError, RuntimeError, AttributeError) as exc:
        for source, old in reversed(applied):
            setattr(source, spec['key'], old)
        settings.batch_message = '批量修改已撤回：' + str(exc)
        return
    settings.batch_message = '已修改 ' + str(len(changes)) + ' 项' + ('；跳过 ' + str(skipped) + ' 项（不适用或只读）' if skipped else '')


class CLM_MMD_BatchValues(bpy.types.PropertyGroup):
    pass


def _batch_field(field, categories, route, key, kind='FLOAT', component=None, enum=None, **kwargs):
    if kind in {'FLOAT','COLOR'} and not enum:kwargs.setdefault('precision',6)
    default = kwargs.get('default', False if kind == 'BOOL' else (enum[0][0] if enum else 0.0))
    _BATCH_FIELDS[field] = dict(categories=set(categories.split()), route=route, key=key,
                               component=component, enum=enum, default=default)
    args = dict(name=key, get=lambda self: _batch_get(self, field), set=lambda self, value: _batch_set(self, field, value), options={'SKIP_SAVE'})
    args.update(kwargs)
    if enum:
        args.pop('default', None)
        prop = EnumProperty(items=[(*entry, n) for n, entry in enumerate(enum)], **args)
    else:
        prop = {'FLOAT': FloatProperty, 'BOOL': BoolProperty, 'INT': IntProperty, 'COLOR': FloatVectorProperty}[kind](**args)
    CLM_MMD_BatchValues.__annotations__[field] = prop


CLM_MMD_BatchValues.__annotations__ = {}
_batch_field('mat_alpha', 'MATERIAL', 'mmd', 'alpha', min=0, max=1, default=1)
_batch_field('mat_edge_weight', 'MATERIAL', 'mmd', 'edge_weight', min=0, default=1)
for key in ('is_double_sided', 'enabled_toon_edge', 'enabled_drop_shadow', 'enabled_self_shadow_map', 'enabled_self_shadow'):
    _batch_field('mat_' + key, 'MATERIAL', 'mmd', key, 'BOOL')
for key, size in [('diffuse_color', 3), ('specular_color', 3), ('ambient_color', 3), ('edge_color', 4)]:
    _batch_field('mat_' + key, 'MATERIAL', 'mmd', key, 'COLOR', size=size, subtype='COLOR', min=0, max=1, default=(1.0,) * size)
_batch_field('mat_shininess', 'MATERIAL', 'mmd', 'shininess', min=0, default=50)
_batch_field('mat_sphere_texture_type', 'MATERIAL', 'mmd', 'sphere_texture_type', enum=[('0','关闭',''),('1','乘算',''),('2','加算',''),('3','子纹理','')])
_batch_field('mat_is_shared_toon_texture', 'MATERIAL', 'mmd', 'is_shared_toon_texture', 'BOOL')
_batch_field('item_shared_toon', 'MATERIAL', 'item', 'shared_toon', enum=[(str(i),'toon'+str(i+1),'') for i in range(10)])
_batch_field('bone_transform_order', 'BONE', 'mmd', 'transform_order', 'INT', default=0)
for key in ('transform_after_dynamics', 'enabled_local_axes', 'is_tip'):
    _batch_field('bone_' + key, 'BONE', 'mmd', key, 'BOOL')
for key in ('local_axis_x','local_axis_z'):
    for n in range(3):
        _batch_field('bone_' + key + '_' + str(n), 'BONE', 'mmd', key, component=n, min=-1, max=1)
_batch_field('data_diffuse_color', 'MATERIAL', 'data', 'diffuse_color', 'COLOR', size=4, subtype='COLOR', min=0, max=1, default=(1.0,) * 4)
for key in ('is_controllable', 'enabled_fixed_axis', 'has_additional_rotation', 'has_additional_location'):
    _batch_field('bone_' + key, 'BONE', 'mmd', key, 'BOOL')
for key in ('bone_rotate', 'bone_move', 'bone_visible'):
    _batch_field('item_' + key, 'BONE', 'item', key, 'BOOL')
_batch_field('bone_additional_transform_influence', 'BONE', 'mmd', 'additional_transform_influence', default=1)
for n in range(3):
    _batch_field('bone_fixed_axis_' + str(n), 'BONE', 'mmd', 'fixed_axis', component=n, min=-1, max=1)
_batch_field('collection_is_visible', 'COLLECTION', 'data', 'is_visible', 'BOOL', default=True)
for key in ('value', 'slider_min', 'slider_max'):
    _batch_field('morph_' + key, 'MORPH', 'data', key, min=-10, max=10)
_batch_field('morph_mute', 'MORPH', 'data', 'mute', 'BOOL')
_batch_field('obj_show_in_front', 'BONE', 'object', 'show_in_front', 'BOOL')
_batch_field('obj_show_axis', 'JOINT', 'object', 'show_axis', 'BOOL')
for key in ('location', 'rotation_euler'):
    for n in range(3):
        _batch_field('obj_' + key + '_' + str(n), 'RIGID JOINT', 'object', key, component=n, subtype='ANGLE' if key == 'rotation_euler' else 'DISTANCE')
_batch_field('rigid_type', 'RIGID', 'mmd', 'type', enum=[('0', '骨骼追随', ''), ('1', '物理', ''), ('2', '物理 + 骨骼', '')])
_batch_field('rigid_shape', 'RIGID', 'mmd', 'shape', enum=[('SPHERE', '球体', ''), ('BOX', '长方体', ''), ('CAPSULE', '胶囊体', '')])
for key in ('size_x', 'size_y', 'size_z'):
    _batch_field('item_' + key, 'RIGID', 'item', key, min=.0001)
_batch_field('item_group', 'RIGID', 'item', 'group', 'INT', min=1, max=16, default=1)
_batch_field('item_ignore_samegroup', 'RIGID', 'item', 'ignore_samegroup', 'BOOL')
for n in range(16):
    _batch_field('mask_' + str(n), 'RIGID', 'mmd', 'collision_group_mask', 'BOOL', component=n)
for key in ('mass', 'friction', 'restitution', 'linear_damping', 'angular_damping'):
    _batch_field('phys_' + key, 'RIGID', 'physics', key, min=0, **({'max': 1} if key != 'mass' else {}))
for kind in ('ang', 'lin'):
    for axis in 'xyz':
        for bound in ('lower', 'upper'):
            key = 'limit_' + kind + '_' + axis + '_' + bound
            _batch_field('joint_' + key, 'JOINT', 'constraint', key, subtype='ANGLE' if kind == 'ang' else 'DISTANCE')
for key in ('spring_linear', 'spring_angular'):
    for n in range(3):
        _batch_field('joint_' + key + '_' + str(n), 'JOINT', 'mmd', key, component=n, min=0)


class _BatchLayout:
    """Use batch proxies only for explicitly allowed fields in this editor."""
    def __init__(self, layout, settings, item):
        object.__setattr__(self, '_layout', layout)
        object.__setattr__(self, '_settings', settings)
        object.__setattr__(self, '_item', item)

    def __setattr__(self, key, value):
        setattr(self._layout, key, value)

    def __getattr__(self, key):
        native = getattr(self._layout, key)
        if key in {'row', 'column', 'box', 'split', 'grid_flow'}:
            return lambda *args, **kwargs: _BatchLayout(native(*args, **kwargs), self._settings, self._item)
        return native

    def prop(self, data, key, **kwargs):
        fields = [(field, spec) for field, spec in _BATCH_FIELDS.items()
                  if self._settings.category in spec['categories'] and key == spec['key']
                  and _batch_source(self._item, spec['route']) == data]
        if not fields:
            return self._layout.prop(data, key, **kwargs)
        index = kwargs.pop('index', None)
        if index is not None:
            fields = [(field, spec) for field, spec in fields if spec['component'] == index]
        if len(fields) > 1:
            split = self._layout.split(factor=.13, align=True)
            split.label(text=kwargs.get('text', key))
            values = split.row(align=False)
            for field, spec in fields:
                axis = 'XYZ'[spec['component']]
                values.column().prop(self._settings.batch, field, text=axis + (' ≠' if batch_mixed(self._settings, field) else ''))
            return
        field, spec = fields[0]
        if batch_mixed(self._settings, field):
            kwargs['text'] = kwargs.get('text', key) + ' ≠'
        return self._layout.prop(self._settings.batch, field, **kwargs)

    def prop_enum(self, data, key, value, **kwargs):
        for field, spec in _BATCH_FIELDS.items():
            if self._settings.category in spec['categories'] and key == spec['key'] and _batch_source(self._item, spec['route']) == data:
                return self._layout.prop_enum(self._settings.batch, field, value, **kwargs)
        return self._layout.prop_enum(data, key, value, **kwargs)


# Display controls filter viewport geometry without changing source meshes.
class CLM_MMD_DisplayMember(bpy.types.PropertyGroup):
    material: PointerProperty(type=bpy.types.Material)
    token: StringProperty()
    obj: PointerProperty(type=bpy.types.Object)
    key: StringProperty()
    kind: StringProperty()
    hidden: BoolProperty()
    disabled: BoolProperty()


class CLM_MMD_DisplayGroup(bpy.types.PropertyGroup):
    root: PointerProperty(type=bpy.types.Object)
    category: StringProperty()
    view_layer: StringProperty()
    layer_token: StringProperty()
    members: CollectionProperty(type=CLM_MMD_DisplayMember)
    solos: CollectionProperty(type=CLM_MMD_Item)


def item_objects(item, settings, context):
    if item.kind=='MORPH' and not item.key.startswith('@'):
        return [obj for obj in morph_meshes(settings.root,item.key) if obj.name in context.view_layer.objects]
    if item.kind == 'MATERIAL':
        return [obj for obj in model_objects(settings.root, context.scene)
                if obj.type == 'MESH' and getattr(obj, 'mmd_type', 'NONE') == 'NONE'
                and any(slot.material == item.material for slot in obj.material_slots)
                and obj.name in context.view_layer.objects]
    return [item.obj] if item.obj and item.obj.name in context.view_layer.objects else []


def _bone_select(arm, names, active):
    if arm.mode == 'EDIT':
        for bone in arm.data.edit_bones:
            bone.select = bone.select_head = bone.select_tail = bone.name in names
        arm.data.edit_bones.active = arm.data.edit_bones.get(active)
    else:
        for bone in arm.pose.bones:
            target = bone if hasattr(bone, 'select') else bone.bone
            target.select = bone.name in names
        arm.data.bones.active = arm.data.bones.get(active)


def _sync_view_selection(context, settings):
    """Apply explicit list selection to Blender; refresh stays inert."""
    items = checked_items(settings)
    current = current_item(settings)
    if settings.category in {'BONE', 'COLLECTION'}:
        arm = armature_of(settings.root, context.scene)
        if not arm or arm.name not in context.view_layer.objects:
            return
        names = set()
        for item in items:
            if item.kind == 'BONE':names.add(item.key)
            else:names.update(b.name for b in collection_members(arm, item_target(item)))
        active = current.key if current and current.kind == 'BONE' and current.selected else None
        if active not in names:active = next((b.name for b in arm.data.bones if b.name in names), '')
        paint = context.object and context.object.mode == 'WEIGHT_PAINT' and root_of(context.object) == settings.root
        if not paint and not (context.object == arm and arm.mode in {'POSE', 'EDIT'}):
            if context.object and context.object.mode != 'OBJECT':bpy.ops.object.mode_set(mode='OBJECT')
            for obj in list(context.selected_objects):obj.select_set(False)
            arm.hide_viewport = False;arm.hide_set(False);arm.select_set(True)
            context.view_layer.objects.active = arm
            bpy.ops.object.mode_set(mode='POSE')
        _bone_select(arm, names, active)
        if paint:
            group = context.object.vertex_groups.get(active)
            context.object.vertex_groups.active_index = group.index if group else -1
        if current and current.kind == 'COLLECTION' and item_target(current):
            arm.data.collections.active = item_target(current)
        arm.show_in_front = True
    else:
        if context.object and context.object.mode != 'OBJECT':bpy.ops.object.mode_set(mode='OBJECT')
        objects = {obj for item in items for obj in item_objects(item, settings, context)}
        for obj in list(context.selected_objects):obj.select_set(False)
        visible = [obj for obj in context.view_layer.objects if obj in objects and obj.visible_get(view_layer=context.view_layer)]
        for obj in visible:obj.select_set(True)
        preferred = item_objects(current, settings, context) if current and current.selected else []
        active = next((obj for obj in preferred if obj in visible), visible[0] if visible else None)
        context.view_layer.objects.active = active
        if active and current:
            if current.kind == 'MATERIAL':
                for obj in visible:
                    slot = next((n for n, s in enumerate(obj.material_slots) if s.material == current.material), None)
                    if slot is not None:obj.active_material_index = slot
            elif current.kind == 'MORPH' and not current.key.startswith('@'):
                for obj in visible:
                    if obj.type=='MESH' and obj.data.shape_keys and current.key in obj.data.shape_keys.key_blocks:
                        obj.active_shape_key_index=obj.data.shape_keys.key_blocks.find(current.key)
    if context.screen:
        for area in context.screen.areas:area.tag_redraw()


def _selection_scope(context, settings):
    return (context.scene.as_pointer(), context.view_layer.as_pointer())


def _native_selection(context, settings):
    """Read only selection/active slots, never editable model properties."""
    active = context.view_layer.objects.active
    selected = tuple(sorted(o.as_pointer() for o in context.view_layer.objects if o.select_get()))
    common = (settings.root.as_pointer() if settings.root else 0, settings.category,
              active.as_pointer() if active else 0, selected)
    if settings.category in {'BONE', 'COLLECTION'}:
        arm = armature_of(settings.root, context.scene)
        bones = arm.data.edit_bones if arm and arm.mode == 'EDIT' else arm.data.bones if arm else ()
        selection_bones = bones if not arm or arm.mode == 'EDIT' else arm.pose.bones
        names = tuple(b.name for b in selection_bones
                      if (b if hasattr(b, 'select') else b.bone).select)
        bone = getattr(bones, 'active', None)
        collection = arm.data.collections.active if arm else None
        paint = active and active.mode == 'WEIGHT_PAINT' and root_of(active) == settings.root
        group = active.vertex_groups.active if paint else None
        return common + (arm.mode if arm else '', names, bone.name if bone else '',
                         collection.name if collection and settings.category == 'COLLECTION' else '',
                         group.name if group else '')
    if settings.category in {'MATERIAL', 'MORPH'}:
        slots = tuple(sorted((o.as_pointer(), o.active_material_index if settings.category == 'MATERIAL'
                              else o.active_shape_key_index)
                             for o in context.view_layer.objects if o.select_get() and o.type == 'MESH'))
        return common + (slots,)
    return common


def _remember_native_selection(context, settings):
    _native_selections[_selection_scope(context, settings)] = _native_selection(context, settings)


def sync_view_selection(context, settings):
    """Record list-origin native state so the watcher preserves batch choices."""
    try:
        _sync_view_selection(context, settings)
    finally:
        _remember_native_selection(context, settings)


def sync_list_selection(context, settings):
    """Reverse sync only an actual native selection change, within the current tab."""
    global _selection_edit
    scope = _selection_scope(context, settings)
    state = _native_selection(context, settings)
    previous = _native_selections.get(scope)
    _native_selections[scope] = state
    if settings.category=='MORPH':
        item=current_item(settings)
        if morph_editor.key(context) in morph_editor._sessions or (item and item.key.startswith('@')):
            return False
    if previous is None or previous[:2] != state[:2] or previous == state:
        return False
    active = context.view_layer.objects.active
    selected = {o for o in context.view_layer.objects if o.select_get()}
    indices, preferred = set(), None
    category = settings.category
    if category in {'BONE', 'COLLECTION'}:
        arm = armature_of(settings.root, context.scene)
        paint = active and active.mode == 'WEIGHT_PAINT' and root_of(active) == settings.root
        available = arm and (arm in selected or paint)
        names, active_name, collection_name, group_name = state[5:9]
        names = set(names) if available else set()
        if paint and group_name and group_name != previous[8]:
            names, active_name = {group_name}, group_name
        if category == 'BONE':
            for n, item in enumerate(settings.items):
                if item.key in names:indices.add(n)
                if item.key == active_name and n in indices:preferred = n
        elif available:
            collection_changed = collection_name != previous[7]
            for n, item in enumerate(settings.items):
                collection = item_target(item)
                members = {b.name for b in collection_members(arm, collection)}
                if ((collection_changed and item.key == collection_name) or
                        (not collection_changed and members and members <= names)):
                    indices.add(n)
                if item.key == collection_name and n in indices:preferred = n
    else:
        for n, item in enumerate(settings.items):
            matches = []
            if category == 'MATERIAL':
                matches = [o for o in selected if o.type == 'MESH' and root_of(o) == settings.root
                           and o.active_material == item.material]
            elif category == 'MORPH':
                matches=[o for o in selected if root_of(o)==settings.root and o.type=='MESH'
                         and o.active_shape_key and o.active_shape_key.name==item.key]
            elif category in {'MESH', 'RIGID', 'JOINT'} and item.obj in selected:
                matches = [item.obj]
            if matches:
                indices.add(n)
                if active in matches:preferred = n
    index = preferred if preferred is not None else settings.index if settings.index in indices else min(indices, default=-1)
    changed = index != settings.index or any(item.selected != (n in indices) for n, item in enumerate(settings.items))
    if not changed:
        return False
    _selection_edit = True
    try:
        for n, item in enumerate(settings.items):item.selected = n in indices
        settings.index = index
        settings['_anchor'] = index
        settings.batch_message = ''
    finally:
        _selection_edit = False
    return True


_DISPLAY_UID = '_clm_visibility_uid'


def _display_uid(target, siblings=()):
    value = target.get(_DISPLAY_UID)
    if not value or any(other != target and other.get(_DISPLAY_UID) == value for other in siblings):
        value = uuid.uuid4().hex
        target[_DISPLAY_UID] = value
    return value


def _group_layer(scene, group):
    named = scene.view_layers.get(group.view_layer)
    if named and (not group.layer_token or named.get(_DISPLAY_UID) == group.layer_token):return named
    matches = [layer for layer in scene.view_layers if group.layer_token and layer.get(_DISPLAY_UID) == group.layer_token]
    return matches[0] if len(matches) == 1 else None


def _display_group(settings, context, create=False):
    use_layer = settings.category in {'MESH', 'RIGID', 'JOINT'}
    for group in settings.display_groups:
        if group.root == settings.root and group.category == settings.category and (
                not use_layer or _group_layer(context.scene, group) == context.view_layer):
            return group
    if create:
        group = settings.display_groups.add()
        group.root, group.category = settings.root, settings.category
        if use_layer:
            group.view_layer = context.view_layer.name
            group.layer_token = _display_uid(context.view_layer, context.scene.view_layers)
        return group
    return None


def _bone_key(obj, key, token=''):
    bones = obj.data.edit_bones if obj.mode == 'EDIT' else obj.data.bones
    bone = bones.get(key)
    if token and (not bone or bone.get(_DISPLAY_UID) != token):
        matches = [b for b in bones if b.get(_DISPLAY_UID) == token]
        bone = matches[0] if len(matches) == 1 else None
    return bone.name if bone else ''


def _same_item(a, b):
    if a.kind != b.kind:return False
    if a.kind == 'MATERIAL':return a.material == b.material
    if a.obj != b.obj:return False
    if a.kind == 'BONE':
        return _bone_key(a.obj, a.key, a.display_token) == _bone_key(b.obj, b.key, b.display_token)
    return a.key == b.key


def _display_sources(item, settings, context):
    if item.kind == 'BONE':
        key = _bone_key(item.obj, item.key, item.display_token)
        return [(item.obj, key, 'BONE')] if key else []
    if item.kind == 'MORPH':return []
    return [(obj, '', 'OBJECT') for obj in item_objects(item, settings, context)]


def _display_target(obj, key, kind):
    if not obj:return None
    if kind == 'BONE':return (obj.data.edit_bones if obj.mode == 'EDIT' else obj.pose.bones if bpy.app.version >= (5, 0, 0) else obj.data.bones).get(key)
    if kind == 'MORPH':
        if key.startswith('@'):
            category,name=key[1:].split('|',1);return morph_api.metadata(obj,category,name)
        keys=getattr(obj.data,'shape_keys',None);return keys.key_blocks.get(key) if keys else None
    return obj


def _hidden(obj, key, kind, context):
    target = _display_target(obj, key, kind)
    if target is None:return True
    if kind == 'OBJECT':return obj.hide_get(view_layer=context.view_layer) or obj.hide_viewport
    return target.mute if kind == 'MORPH' else target.hide


def _set_hidden(obj, key, kind, hidden, context, disabled=False):
    target = _display_target(obj, key, kind)
    if target is None:return
    if kind == 'OBJECT':
        if obj.name not in context.view_layer.objects:return
        obj.hide_viewport = disabled
        obj.hide_set(hidden, view_layer=context.view_layer)
    elif kind == 'MORPH':target.mute = hidden
    else:target.hide = hidden


def display_state(item, settings, context):
    target = item_target(item)
    if item.kind == 'COLLECTION':
        return target.is_visible, target.is_solo, not item.obj.data.collections.is_solo_active
    group = _display_group(settings, context)
    if item.kind == 'MATERIAL':
        return not _material_hidden(group, item.material), bool(group and any(x.material == item.material for x in group.solos)), not bool(group and group.solos)
    solo = bool(group and any(_same_item(item, x) for x in group.solos))
    sources = _display_sources(item, settings, context)
    visible = any(not _hidden(*source, context) for source in sources)
    return visible, solo, bool(sources) and not bool(group and len(group.solos))


def _restore_display(group, context):
    if group.category == 'MATERIAL':
        group.solos.clear()
        sync_material_preview(context, context.scene.clm_mmd_workspace)
        return
    for member in group.members:
        if member.obj:
            key = _bone_key(member.obj, member.key, member.token) if member.kind == 'BONE' else member.key
            _set_hidden(member.obj, key, member.kind, member.hidden, context, member.disabled)
    group.members.clear()
    group.solos.clear()


def _toggle_display(context, settings, item, action):
    if item_target(item) is None or root_of(item.obj) != settings.root:return
    if item.kind == 'COLLECTION':
        target = item_target(item)
        if action == 'SOLO':target.is_solo = not target.is_solo
        elif not item.obj.data.collections.is_solo_active:target.is_visible = not target.is_visible
        return
    if item.kind == 'MATERIAL':
        if action == 'VISIBLE':
            set_item_visible(context, settings, item, not display_state(item, settings, context)[0])
            return
        group = _display_group(settings, context, create=True)
        existing = next((n for n, row in enumerate(group.solos) if row.material == item.material), None)
        if existing is not None:group.solos.remove(existing)
        else:
            solo = group.solos.add();solo.material = item.material;solo.obj = item.obj;solo.kind = 'MATERIAL'
        sync_material_preview(context, settings)
        return
    sources = _display_sources(item, settings, context)
    if not sources:return
    group = _display_group(settings, context, create=True)
    if action == 'VISIBLE':
        if group.solos:return
        hide = any(not _hidden(*source, context) for source in sources)
        for source in sources:_set_hidden(*source, hide, context)
        return
    if not group.solos:
        group.members.clear()
        seen = set()
        for row in settings.items:
            for obj, key, kind in _display_sources(row, settings, context):
                identity = (obj.as_pointer(), key, kind)
                if identity in seen:continue
                seen.add(identity)
                member = group.members.add();member.obj, member.key, member.kind = obj, key, kind
                member.hidden = obj.hide_get(view_layer=context.view_layer) if kind == 'OBJECT' else _hidden(obj, key, kind, context)
                member.disabled = obj.hide_viewport if kind == 'OBJECT' else False
                if kind == 'BONE':member.token = _display_uid((obj.data.edit_bones if obj.mode == 'EDIT' else obj.data.bones).get(key), obj.data.edit_bones if obj.mode == 'EDIT' else obj.data.bones)
    existing = next((n for n, x in enumerate(group.solos) if _same_item(item, x)), None)
    if existing is not None:group.solos.remove(existing)
    else:
        solo = group.solos.add()
        solo.obj, solo.material, solo.key, solo.kind = item.obj, item.material, item.key, item.kind
        if item.kind == 'BONE':solo.display_token = _display_uid((item.obj.data.edit_bones if item.obj.mode == 'EDIT' else item.obj.data.bones).get(item.key))
    if not group.solos:
        _restore_display(group, context)
        return
    wanted = {(obj.as_pointer(), key, kind) for solo in group.solos if solo.obj or (solo.kind == 'MATERIAL' and solo.material)
              for obj, key, kind in _display_sources(solo, settings, context)}
    for member in group.members:
        if member.obj:
            key = _bone_key(member.obj, member.key, member.token) if member.kind == 'BONE' else member.key
            identity = (member.obj.as_pointer(), key, member.kind)
            _set_hidden(member.obj, key, member.kind, identity not in wanted, context)


def toggle_display(context, settings, item, action):
    try:
        return _toggle_display(context, settings, item, action)
    finally:
        _remember_native_selection(context, settings)


class CLM_MMD_OT_DisplayAll(bpy.types.Operator):
    bl_idname = 'clm_mmd.display_all'
    bl_label = '全显 / 全隐'
    bl_options = {'REGISTER', 'UNDO'}
    visible: BoolProperty(default=True)

    @classmethod
    def description(cls, context, properties):
        return '显示当前模型此栏目全部项目，并取消单独显示' if properties.visible else '隐藏当前模型此栏目全部项目，并取消单独显示'

    def execute(self, context):
        settings = context.scene.clm_mmd_workspace
        if not settings.root or settings.category in {'INFO', 'MORPH'}:return {'CANCELLED'}
        # All means the whole category, independent of search and selection.
        if settings.category == 'COLLECTION':
            arm = armature_of(settings.root, context.scene)
            if arm:
                for collection in arm.data.collections_all:collection.is_solo = False
                for collection in arm.data.collections_all:collection.is_visible = self.visible
        else:
            group = _display_group(settings, context)
            if group and group.solos:_restore_display(group, context)
            if settings.category == 'MATERIAL':
                group = _display_group(settings, context, create=True)
                for item in settings.items:
                    if item_target(item) is None or root_of(item.obj) != settings.root:continue
                    member = next((x for x in group.members if x.material == item.material), None)
                    if member is None:
                        member = group.members.add();member.kind = 'MATERIAL';member.material = item.material
                    member.hidden = not self.visible
                sync_material_preview(context, settings)
            else:
                for item in settings.items:set_item_visible(context, settings, item, self.visible)
        _remember_native_selection(context, settings)
        if context.screen:
            for area in context.screen.areas:area.tag_redraw()
        return {'FINISHED'}


class CLM_MMD_OT_DisplayItem(bpy.types.Operator):
    bl_idname = 'clm_mmd.display_item'
    bl_label = '可见 / 单独显示'
    bl_options = {'REGISTER', 'UNDO'}
    index: IntProperty()
    action: EnumProperty(items=[('VISIBLE', '可见', '切换视图可见；材质只控制使用它的面'), ('SOLO', '单独显示', '只显示星标条目；取消最后一个星标恢复原可见状态'), ('RESET', '取消独显', '恢复独显前的可见状态')])

    @classmethod
    def description(cls, context, properties):
        return ('可见：材质只控制使用它的面' if properties.action == 'VISIBLE'
                else '单独显示：可启用多个星标；关闭最后一个恢复原可见状态')

    def execute(self, context):
        settings = context.scene.clm_mmd_workspace
        if self.action == 'RESET':
            if settings.category == 'COLLECTION':
                arm = armature_of(settings.root, context.scene)
                if arm:
                    for collection in arm.data.collections_all:collection.is_solo = False
            else:
                group = _display_group(settings, context)
                if group:_restore_display(group, context)
            return {'FINISHED'}
        if not 0 <= self.index < len(settings.items):return {'CANCELLED'}
        try:toggle_display(context, settings, settings.items[self.index], self.action)
        except (RuntimeError, AttributeError) as exc:
            self.report({'WARNING'}, str(exc));return {'CANCELLED'}
        if context.screen:
            for area in context.screen.areas:area.tag_redraw()
        return {'FINISHED'}



def collection_members(arm, collection):
    """Edit bones own current membership until Edit mode is committed."""
    if not arm or not collection:
        return []
    if arm.mode == 'EDIT':
        return [b for b in arm.data.edit_bones if collection in b.collections[:]]
    return list(collection.bones)


def refresh_collection_members(context, settings):
    arm = armature_of(settings.root, context.scene)
    collection = arm.data.collections.active if arm else None
    bones = collection_members(arm, collection)
    names = [b.name for b in bones]
    if names != [i.name for i in settings.collection_members]:
        settings.collection_members.clear()
        for name in names:
            settings.collection_members.add().name = name
    active = (arm.data.edit_bones.active if arm.mode == 'EDIT' else arm.data.bones.active) if arm else None
    settings['member_index'] = names.index(active.name) if active and active.name in names else -1


def collection_arm(context):
    settings = context.scene.clm_mmd_workspace
    arm = armature_of(settings.root, context.scene)
    if not arm or arm.name not in context.view_layer.objects:
        raise ValueError('当前视图层没有模型骨架')
    if not arm.data.is_editable:
        raise ValueError('链接骨架不可编辑')
    return arm


class CLM_MMD_CollectionMember(bpy.types.PropertyGroup):
    pass


class CLM_MMD_OT_CollectionAction(bpy.types.Operator):
    bl_idname = 'clm_mmd.collection_action'
    bl_label = '管理骨骼集合'
    bl_description = '操作当前原生骨骼集合；移除集合或成员不会删除骨骼'
    bl_options = {'REGISTER', 'UNDO'}
    action: EnumProperty(items=[('ADD', '增加集合', ''), ('ADD_CHILD', '增加子集合', ''),
        ('REMOVE', '移除集合', ''), ('UP', '上移集合', ''), ('DOWN', '下移集合', ''),
        ('ASSIGN', '分配所选骨骼', ''), ('UNASSIGN', '移除所选成员', '')])
    member: StringProperty(options={'SKIP_SAVE'})

    def execute(self, context):
        try:
            arm = collection_arm(context)
            collection = arm.data.collections.active
            if self.action != 'ADD' and not collection:
                raise ValueError('请先选择骨骼集合')
            if collection and self.action != 'ADD' and not collection.is_editable:
                raise ValueError('链接骨骼集合不可编辑')
            if self.action in {'ADD', 'ADD_CHILD'}:
                arm.data.collections.active = arm.data.collections.new('骨骼集合', parent=collection if self.action == 'ADD_CHILD' else None)
            elif self.action == 'REMOVE':
                arm.data.collections.remove(collection)
            elif self.action in {'UP', 'DOWN'}:
                # Native collection_move also handles siblings in a nested hierarchy.
                with context.temp_override(object=arm, active_object=arm, armature=arm.data):
                    result = bpy.ops.armature.collection_move(direction=self.action)
                if 'FINISHED' not in result:
                    return {'CANCELLED'}
            else:
                if context.view_layer.objects.active != arm or arm.mode not in {'POSE', 'EDIT'}:
                    raise ValueError('请在当前模型的姿态或编辑模式中选择骨骼')
                bones = arm.data.edit_bones if arm.mode == 'EDIT' else arm.data.bones
                if self.member:
                    bone = bones.get(self.member)
                    if not bone or bone not in collection_members(arm, collection):
                        raise ValueError('成员已不在此集合中')
                    chosen = [bone]
                else:
                    chosen = [b for b in bones if (b if hasattr(b, 'select') else arm.pose.bones[b.name]).select]
                if not chosen:
                    raise ValueError('请先选择骨骼')
                for bone in chosen:
                    if self.action == 'ASSIGN':
                        collection.assign(bone)
                    else:
                        collection.unassign(bone)
            settings = context.scene.clm_mmd_workspace
            refresh(context)
            active = arm.data.collections.active
            if active:
                for index, item in enumerate(settings.items):
                    item.selected = item.key == active.name
                    if item.selected:
                        # Suppress the list index callback: collection edits must not
                        # replace native bone selection, mode, or object selection.
                        settings['index'] = index
            refresh_collection_members(context, settings)
            _remember_native_selection(context, settings)
            if context.screen:
                for area in context.screen.areas:
                    area.tag_redraw()
        except (ValueError, RuntimeError, TypeError) as exc:
            self.report({'WARNING'}, str(exc))
            return {'CANCELLED'}
        return {'FINISHED'}


class CLM_MMD_OT_CollectionMemberSelect(bpy.types.Operator):
    bl_idname = 'clm_mmd.collection_member_select'
    bl_label = '选择集合成员'
    bl_description = '选择骨骼；Ctrl 切换选择，Shift 连续选择'
    name: StringProperty()
    extend: BoolProperty(options={'SKIP_SAVE'})
    range_select: BoolProperty(options={'SKIP_SAVE'})

    def invoke(self, context, event):
        self.extend, self.range_select = event.ctrl, event.shift
        return self.execute(context)

    def execute(self, context):
        try:
            arm = collection_arm(context)
            if context.view_layer.objects.active != arm or arm.mode not in {'POSE', 'EDIT'}:
                raise ValueError('请在当前模型的姿态或编辑模式中选择骨骼')
            members = collection_members(arm, arm.data.collections.active)
            order = [b.name for b in members]
            if self.name not in order:
                raise ValueError('成员已不在此集合中')
            bones = arm.data.edit_bones if arm.mode == 'EDIT' else arm.data.bones
            names = {b.name for b in bones if (b if hasattr(b, 'select') else arm.pose.bones[b.name]).select}
            if self.range_select and bones.active and bones.active.name in order:
                start, end = sorted((order.index(bones.active.name), order.index(self.name)))
                names.update(order[start:end + 1])
            elif self.extend:
                if self.name in names:
                    names.remove(self.name)
                else:
                    names.add(self.name)
            else:
                names = {self.name}
            _bone_select(arm, names, self.name if self.name in names else next(iter(names), ''))
            refresh_collection_members(context, context.scene.clm_mmd_workspace)
            _remember_native_selection(context, context.scene.clm_mmd_workspace)
            if context.screen:
                for area in context.screen.areas:
                    area.tag_redraw()
        except (ValueError, RuntimeError) as exc:
            self.report({'WARNING'}, str(exc))
            return {'CANCELLED'}
        return {'FINISHED'}


class CLM_MMD_UL_CollectionMembers(bpy.types.UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        arm = armature_of(data.root, context.scene)
        bones = arm.data.edit_bones if arm and arm.mode == 'EDIT' else arm.data.bones if arm else None
        bone = bones.get(item.name) if bones else None
        if not bone:
            layout.label(text=item.name)
            return
        selected = (bone if hasattr(bone, 'select') else arm.pose.bones[bone.name]).select
        row = layout.row(align=True)
        row.operator_context = 'INVOKE_DEFAULT'
        row.operator('clm_mmd.collection_member_select', text='', icon='BONE_DATA', depress=selected).name = bone.name
        row.prop(bone, 'name', text='')
        remove = row.operator('clm_mmd.collection_action', text='', icon='REMOVE')
        remove.action, remove.member = 'UNASSIGN', bone.name


def draw_collection(layout, context, settings, arm, collection):
    layout.prop(collection, 'name', text='骨骼集')
    layout.prop(collection, 'is_visible', text='显示')
    parent = layout.row()
    parent.enabled = arm.data.is_editable and collection.is_editable
    parent.prop(collection, 'parent', text='父集合')
    box = layout.box()
    box.label(text='成员骨骼 · ' + str(len(settings.collection_members)))
    box.template_list('CLM_MMD_UL_CollectionMembers', '', settings, 'collection_members', settings, 'member_index', rows=8)
    actions = box.row(align=True)
    actions.enabled = arm.data.is_editable and collection.is_editable and context.view_layer.objects.active == arm and arm.mode in {'POSE', 'EDIT'}
    actions.operator('clm_mmd.collection_action', text='分配所选', icon='ADD').action = 'ASSIGN'
    actions.operator('clm_mmd.collection_action', text='移除所选', icon='REMOVE').action = 'UNASSIGN'
    if context.view_layer.objects.active != arm or arm.mode not in {'POSE', 'EDIT'}:
        box.label(text='在姿态或编辑模式中选择骨骼', icon='INFO')
    layout.label(text='MMD 显示枠请使用 MMD Tools')


def _member_index_changed(settings, context):
    if _refreshing or not 0 <= settings.member_index < len(settings.collection_members):
        return
    arm = armature_of(settings.root, context.scene)
    if arm and context.view_layer.objects.active == arm and arm.mode in {'POSE', 'EDIT'}:
        bpy.ops.clm_mmd.collection_member_select(name=settings.collection_members[settings.member_index].name)


class CLM_MMD_Settings(bpy.types.PropertyGroup):
    pmx_export_scale:FloatProperty(name='PMX 导出倍率',min=.0001,precision=6,get=_physics_export_scale_get,set=_physics_export_scale_set)
    physics_ring_center:PointerProperty(name='裙筒中心',description='留空时使用模型骨架原点；可指定裙筒中心的对象',type=bpy.types.Object)
    physics_rigid_anchor:EnumProperty(name='对齐位置',items=[('CENTER','骨骼中点',''),('HEAD','骨骼起点',''),('TAIL','骨骼末端','')],default='CENTER')
    morph_filter: EnumProperty(name='分类筛选',items=[('ALL','全部','')]+morph_api.CATEGORIES,default='ALL')
    morph_show_originals: BoolProperty(name='显示原始子表情',description='显示批量附加后移入隐藏分类的原始表情',default=False)
    morph_show_meshes: BoolProperty(name='关联网格',default=False)
    binding_section: EnumProperty(items=[("BONES", "骨骼与权重", "顶点分组、引导线与骨链绑定"), ("PHYSICS", "刚体与 J 点", "使用已有骨链生成或调整物理")], default="BONES")
    collection_members: CollectionProperty(type=CLM_MMD_CollectionMember)
    member_index: IntProperty(default=-1, update=_member_index_changed)
    display_groups: CollectionProperty(type=CLM_MMD_DisplayGroup)
    name_language: EnumProperty(items=[('JP', '日', '日文名称'), ('EN', '英', '英文名称')], default='JP')
    root: PointerProperty(name="模型", type=bpy.types.Object, poll=_root_poll, update=_changed)
    lock_model: BoolProperty(name="锁定模型", default=True)
    category: EnumProperty(name="分类", items=CATEGORIES, default='RIGID', update=_changed)
    items: CollectionProperty(type=CLM_MMD_Item)
    batch: PointerProperty(type=CLM_MMD_BatchValues)
    batch_message: StringProperty(options={'SKIP_SAVE'})
    filter_text: StringProperty(name='筛选', options={'TEXTEDIT_UPDATE'})
    index: IntProperty(default=0, update=_index_changed)
    list_fraction: FloatProperty(name="列表宽度", min=.2, max=.5, default=.30, subtype='FACTOR')
    list_rows: IntProperty(name="列表行数", min=3, max=25, default=7)
    show_english: BoolProperty(name="英文名称")
    show_transform: BoolProperty(name="位置与旋转")
    show_collision: BoolProperty(name="碰撞")
    show_dynamics: BoolProperty(name="动力学")
    show_axes: BoolProperty(name="轴向与追加变换")
    show_joint_linear: BoolProperty(name="位移限制")
    show_joint_spring: BoolProperty(name="弹簧")
    show_display: BoolProperty(name="列表设置")


class CLM_MMD_UL_Items(bpy.types.UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        icons = dict((c[0], c[3]) for c in CATEGORIES)
        split = layout.split(factor=min(.22, max(.105, .015 + .05 * len(str(max(0, len(data.items) - 1))))), align=True)
        number = split.row(align=True);number.alignment = 'RIGHT';number.ui_units_x = max(1.5, .65 * len(str(max(0, len(data.items) - 1))))
        number.label(text=str(index))
        row = split.row(align=True)
        row.operator_context = 'INVOKE_DEFAULT'
        # Keep the list for names; owner mesh/model is a dedicated detail field.
        text=_morph_identity(item)[1] if item.kind=='MORPH' else item.name
        item_icon=icons.get(item.kind,'OBJECT_DATA')
        if item.kind=='MORPH':
            item_icon={'vertex_morphs':'SHAPEKEY_DATA','bone_morphs':'BONE_DATA','material_morphs':'MATERIAL','uv_morphs':'UV','group_morphs':'NODETREE'}[_morph_identity(item)[0]]
        op = row.operator('clm_mmd.select_item', text=text, icon=item_icon, emboss=True, depress=item.selected)
        op.index = index
        if item.kind == 'MORPH':
            return
        visible, solo, eye_enabled = display_state(item, data, context)
        eye = row.row(align=True);eye.enabled = eye_enabled
        eye.prop(item, 'visible', text='', emboss=False, icon='HIDE_OFF' if visible else 'HIDE_ON')
        star = row.row(align=True)
        op = star.operator('clm_mmd.display_item', text='', emboss=False, icon='SOLO_ON' if solo else 'SOLO_OFF', depress=solo)
        op.index, op.action = index, 'SOLO'

    def draw_filter(self, context, layout):
        layout.prop(context.scene.clm_mmd_workspace, 'filter_text', text='', icon='VIEWZOOM')

    def filter_items(self, context, data, propname):
        items = getattr(data, propname)
        visible = set(visible_indices(data))
        flags = [self.bitflag_filter_item if n in visible else 0 for n in range(len(items))]
        return flags, []


class CLM_MMD_OT_Refresh(bpy.types.Operator):
    bl_idname = "clm_mmd.refresh"
    bl_label = "刷新模型列表"
    def execute(self, context):
        refresh(context)
        return {'FINISHED'}


class CLM_MMD_OT_EditItem(bpy.types.Operator):
    bl_idname = "clm_mmd.edit_item"
    bl_label = "视图编辑"
    bl_description = "激活查看的对象；骨骼进入姿态模式，刚体与 Joint 进入物体模式"
    bl_options = {'REGISTER', 'UNDO'}
    def execute(self, context):
        s = context.scene.clm_mmd_workspace
        item = current_item(s)
        target = item_target(item)
        if target is None or not item.obj or item.obj.name not in context.view_layer.objects:
            self.report({'WARNING'}, "目标已删除或不在当前视图层，请刷新")
            return {'CANCELLED'}
        obj = item.obj
        if root_of(obj) != s.root:
            self.report({'ERROR'}, "条目不属于当前模型")
            return {'CANCELLED'}
        try:
            if context.object and context.object.mode != 'OBJECT':
                bpy.ops.object.mode_set(mode='OBJECT')
            for selected in list(context.selected_objects):
                selected.select_set(False)
            obj.hide_viewport = False
            obj.hide_set(False)
            obj.select_set(True)
            context.view_layer.objects.active = obj
            if item.kind == 'BONE':
                obj.data.bones.active = obj.data.bones.get(item.key)
                bpy.ops.object.mode_set(mode='POSE')
                for pb in obj.pose.bones:
                    if hasattr(pb, 'select'):
                        pb.select = pb.name == item.key
                    else:
                        pb.bone.select = pb.name == item.key
                obj.show_in_front = True
            elif item.kind == 'MORPH' and getattr(obj.data,'shape_keys',None):
                obj.active_shape_key_index = obj.data.shape_keys.key_blocks.find(item.key)
            elif item.kind == 'MATERIAL':
                obj.active_material_index = next((i for i, slot in enumerate(obj.material_slots) if slot.material == item.material), 0)
            elif item.kind == 'COLLECTION':
                obj.data.collections.active = target
        except RuntimeError as exc:
            self.report({'ERROR'}, str(exc))
            return {'CANCELLED'}
        return {'FINISHED'}


def validate_physics(root, scene):
    for obj in model_objects(root, scene):
        if getattr(obj, 'mmd_type', '') != 'JOINT':
            continue
        c = obj.rigid_body_constraint
        if not c or not c.object1 or not c.object2 or c.object1 == c.object2:
            raise ValueError("Joint " + obj.name + " 的连接刚体无效")
        for body in (c.object1, c.object2):
            if root_of(body) != root or getattr(body, 'mmd_type', '') != 'RIGID_BODY' or not body.rigid_body:
                raise ValueError("Joint " + obj.name + " 连接了其他模型或非刚体")
        for kind in ('lin', 'ang'):
            for axis in 'xyz':
                if getattr(c, 'limit_' + kind + '_' + axis + '_lower') > getattr(c, 'limit_' + kind + '_' + axis + '_upper'):
                    raise ValueError("Joint " + obj.name + " 的 " + axis.upper() + " 下限大于上限")


class CLM_MMD_OT_Physics(bpy.types.Operator):
    bl_idname = "clm_mmd.physics"
    bl_label = "MMD 物理"
    bl_options = {'REGISTER', 'UNDO'}
    action: EnumProperty(items=[('BUILD', '构建物理', ''), ('CLEAN', '清理构建', '')])
    def execute(self, context):
        root = context.scene.clm_mmd_workspace.root
        if not root or root.name not in context.view_layer.objects:
            self.report({'ERROR'}, "请先选择当前视图层中的 MMD 模型")
            return {'CANCELLED'}
        previous = context.object
        previous_name = previous.name if previous else None
        selected_names = [obj.name for obj in context.selected_objects]
        previous_mode = previous.mode if previous else 'OBJECT'
        try:
            if self.action == 'BUILD':
                validate_physics(root, context.scene)
                if root.mmd_root.is_built:
                    self.report({'WARNING'}, "物理已构建，请先清理构建")
                    return {'CANCELLED'}
            if context.screen and context.screen.is_animation_playing:
                bpy.ops.screen.animation_cancel(restore_frame=False)
            if previous and previous.mode != 'OBJECT':
                bpy.ops.object.mode_set(mode='OBJECT')
            context.scene.frame_set(context.scene.frame_start)
            context.view_layer.objects.active = root
            operator = bpy.ops.mmd_tools.build_rig if self.action == 'BUILD' else bpy.ops.mmd_tools.clean_rig
            result = operator()
            if 'FINISHED' not in result:
                return {'CANCELLED'}
        except (RuntimeError, ValueError, AttributeError) as exc:
            self.report({'ERROR'}, str(exc))
            return {'CANCELLED'}
        finally:
            for obj in list(context.selected_objects):
                obj.select_set(False)
            for name in selected_names:
                obj = context.view_layer.objects.get(name)
                if obj is not None:
                    obj.select_set(True)
            previous = context.view_layer.objects.get(previous_name) if previous_name else None
            if previous is not None:
                context.view_layer.objects.active = previous
                if previous_mode != 'OBJECT' and previous.mode == 'OBJECT':
                    try:
                        bpy.ops.object.mode_set(mode=previous_mode)
                    except RuntimeError:
                        pass
        refresh(context)
        return {'FINISHED'}


_scene_panel_filters = []


def _scene_panels():
    pending, result, seen = list(bpy.types.Panel.__subclasses__()), [], set()
    while pending:
        cls = pending.pop(0)
        if cls in seen:
            continue
        seen.add(cls);pending.extend(cls.__subclasses__())
        if (getattr(cls, 'bl_space_type', '') == 'PROPERTIES' and
                getattr(cls, 'is_registered', False) and cls.__name__ not in {'CLM_MMD_PT_Manager', 'CLM_MMD_PT_Binding'}):
            result.append(cls)
    ordered, remaining = [], list(result)
    ids = {getattr(cls, 'bl_idname', cls.__name__) or cls.__name__: cls for cls in result}
    while remaining:
        ready = [cls for cls in remaining if ids.get(getattr(cls, 'bl_parent_id', '')) not in remaining]
        if not ready:
            ready = [remaining[0]]
        ordered.extend(ready)
        for cls in ready:remaining.remove(cls)
    return ordered


def _filter_scene_panels():
    known = {entry[0] for entry in _scene_panel_filters}
    panels = [cls for cls in _scene_panels() if cls not in known]
    if not panels:
        return
    entries = [(cls, cls.__dict__.get('poll'), getattr(cls, 'poll', None)) for cls in panels]
    for cls in reversed(panels):bpy.utils.unregister_class(cls)
    for cls, descriptor, original in entries:
        def make_poll(original):
            def poll(cls, context):
                if _registered and ((manager_area(context) and getattr(cls, "bl_context", "") == "scene") or binding_area(context)):
                    return False
                return original(context) if original else True
            return classmethod(poll)
        wrapper = make_poll(original)
        cls.poll = wrapper
        bpy.utils.register_class(cls)
        _scene_panel_filters.append((cls, descriptor, wrapper))


def _restore_scene_panels():
    entries = list(_scene_panel_filters)
    live = {cls for cls, _, _ in entries if getattr(cls, 'is_registered', False)}
    for cls, descriptor, wrapper in reversed(entries):
        if cls in live:bpy.utils.unregister_class(cls)
    for cls, descriptor, wrapper in entries:
        if cls.__dict__.get('poll') is wrapper:
            if descriptor is None:delattr(cls, 'poll')
            else:cls.poll = descriptor
        if cls in live:bpy.utils.register_class(cls)
    _scene_panel_filters.clear()


def manager_area(context):
    if not context.workspace or not context.workspace.get(MARKER) or not context.area:
        return False
    areas = [a for a in context.screen.areas if a.type == 'PROPERTIES']
    return len(areas) >= 2 and context.area == max(areas, key=lambda a: (a.y, a.x))



def binding_area(context):
    return False


def fold(layout, settings, prop, label):
    row = layout.row(align=True)
    row.prop(settings, prop, text=label, icon='TRIA_DOWN' if getattr(settings, prop) else 'TRIA_RIGHT', emboss=False)
    return layout.column(align=True) if getattr(settings, prop) else None


def prop(layout, data, key, text=None, **kwargs):
    if data is not None and hasattr(data, key):
        layout.prop(data, key, text=text if text is not None else "", **kwargs)


def draw_names(layout, settings, data):
    row = layout.row(align=True)
    prop(row, data, 'name_e' if settings.name_language == 'EN' else 'name_j', '名称')
    language = row.row(align=True);language.ui_units_x = 3.0
    language.prop(settings, 'name_language', expand=True)


def _vector_row(layout, data, key, label,wide=False):
    if wide:
        values=layout.column(align=True)
        for index,axis in enumerate('XYZ'):values.prop(data,key,index=index,text=label+' '+axis)
        return
    row = layout.split(factor=.14, align=True)
    row.label(text=label)
    values = row.row(align=True)
    for index, axis in enumerate('XYZ'):
        cell = values.split(factor=.18, align=True)
        cell.label(text=axis)
        cell.prop(data, key, index=index, text='')


def draw_rigid(layout, context, item, s):
    obj, r = item.obj, item.obj.mmd_rigid
    draw_names(layout, s, r)
    arm = armature_of(s.root, context.scene)
    if arm:
        layout.prop_search(r, 'bone', arm.pose, 'bones', text='关联骨骼')
    draw_physics_alignment(layout,s,rigid=True)
    header = layout.split(factor=.5, align=True)
    mode = header.box().column(align=True);mode.label(text='模式')
    mode.row(align=True).prop(r, 'type', text='', expand=True)
    shape = header.box().column(align=True);shape.label(text='形状')
    shape.enabled = obj.mode == 'OBJECT'
    buttons = shape.row(align=True)
    for value, title in [('SPHERE', '球体'), ('CAPSULE', '胶囊'), ('BOX', '方盒')]:
        buttons.prop_enum(r, 'shape', value, text=title)
    row = layout.split(factor=.5, align=True)
    collision = row.box().column(align=True)
    group = collision.row(align=True)
    group.prop(item, 'group', text='碰撞组')
    group.prop(item, 'ignore_samegroup', text='忽略同组碰撞')
    collision.label(text='不碰撞组（多选）')
    for start in range(0, 16, 8):
        masks = collision.row(align=True)
        for i in range(start, start + 8):
            masks.prop(r, 'collision_group_mask', index=i, text=str(i + 1), toggle=True)
    spatial = row.box().column(align=True)
    spatial.label(text='尺寸（最终 PMX 数值）')
    spatial.prop(s,'pmx_export_scale',text='导出倍率')
    size = spatial.column(align=True);size.enabled = obj.mode == 'OBJECT'
    labels = [('size_x', '半宽 X'), ('size_y', '半高 Y'), ('size_z', '半深 Z')] if r.shape == 'BOX' else [('size_x', '半径')]+([('size_y','柱段高度')] if r.shape=='CAPSULE' else [])
    for key,label in labels:size.prop(item,key,text=label)
    spatial.separator()
    _vector_row(spatial, obj, 'location', '位置',wide=True)
    _vector_row(spatial, obj, 'rotation_euler', '旋转',wide=True)
    if obj.rigid_body:
        physics = layout.box().column(align=True);physics.label(text='物理演算参数')
        mass = physics.row(align=True);mass.enabled = r.type != '0'
        mass.prop(obj.rigid_body, 'mass', text='质量')
        for damp, other, damp_label, other_label in [('linear_damping','restitution','移动衰减','反弹力'),('angular_damping','friction','旋转衰减','摩擦力')]:
            params = physics.row(align=True)
            left = params.row(align=True);left.enabled = r.type != '0'
            left.prop(obj.rigid_body, damp, text=damp_label)
            params.prop(obj.rigid_body, other, text=other_label)


def draw_joint_limits(layout, constraint, kind):
    table = layout.column(align=True)
    for axis in 'xyz':
        row = table.split(factor=.18, align=True);row.label(text=axis.upper())
        values = row.row(align=True)
        lo, hi = 'limit_' + kind + '_' + axis + '_lower', 'limit_' + kind + '_' + axis + '_upper'
        values.alert = getattr(constraint, lo) > getattr(constraint, hi)
        values.prop(constraint, lo, text='');values.prop(constraint, hi, text='')
    footer = table.split(factor=.18, align=True);footer.label(text='')
    labels = footer.row(align=True);labels.label(text='下限');labels.label(text='上限')


def draw_joint(layout, context, item, s):
    obj, j = item.obj, item.obj.mmd_joint;draw_names(layout, s, j);c = obj.rigid_body_constraint
    if not c:
        layout.label(text='缺少刚体约束', icon='ERROR');return
    draw_physics_alignment(layout,s,rigid=False)
    row = layout.row(align=True);row.prop(c, 'object1', text='刚体 A');row.prop(c, 'object2', text='B')
    if not c.object1 or not c.object2 or c.object1 == c.object2 or any(root_of(o) != s.root for o in (c.object1, c.object2) if o):
        layout.label(text='连接对无效或跨模型', icon='ERROR')
    _vector_row(layout, obj, 'location', '位置',wide=True)
    _vector_row(layout, obj, 'rotation_euler', '旋转',wide=True)
    limits = layout.box().row(align=True)
    for kind, label in [('lin', '移动限制'), ('ang', '旋转限制')]:
        col = limits.column(align=True);col.label(text=label);draw_joint_limits(col, c, kind)
    _vector_row(layout, j, 'spring_linear', '移动弹簧',wide=True)
    _vector_row(layout, j, 'spring_angular', '旋转弹簧',wide=True)
    layout.prop(obj, 'show_axis', text='显示局部轴')


def draw_physics_alignment(layout,s,rigid):
    row=layout.row(align=True)
    row.operator('clm_mmd.align_physics_to_bone',text='对齐骨骼位置',icon='BONE_DATA').orientation='BONE'
    row.operator('clm_mmd.align_physics_to_bone',text='裙筒环向对齐').orientation='RADIAL'
    if rigid:layout.prop(s,'physics_rigid_anchor',text='对齐位置')
    layout.prop(s,'physics_ring_center',text='裙筒中心')


def draw_material(layout, context, item, s, material):
    m = material.mmd_material;draw_names(layout, s, m)
    color = layout.box().column(align=True);color.label(text='材质色')
    for key, label, numeric, numeric_label in [('diffuse_color','漫射颜色','alpha','Alpha'),('specular_color','高光颜色','shininess','反射'),('ambient_color','环境色',None,'')]:
        row = color.split(factor=.58, align=True)
        swatch = row.split(factor=.25, align=True);swatch.label(text=label);swatch.prop(m, key, text='')
        if numeric:row.prop(m, numeric, text=numeric_label)
        else:row.label(text='')
    row = layout.box().split(factor=.5, align=True)
    drawing = row.column(align=True);drawing.label(text='描绘')
    for pair in [(('is_double_sided','双面描绘'),('enabled_self_shadow_map','本影显示')),(('enabled_drop_shadow','地面影'),('enabled_self_shadow','本影'))]:
        flags = drawing.row(align=True)
        for key, label in pair:flags.prop(m, key, text=label)
    edge = row.column(align=True);edge.label(text='轮廓线')
    flags = edge.row(align=True);flags.prop(m, 'enabled_toon_edge', text='有效');flags.prop(m, 'edge_weight', text='尺寸')
    edge.prop(m, 'edge_color', text='颜色')
    texture = layout.box().column(align=True);texture.label(text='材质纹理')
    row = texture.split(factor=.52, align=True);files = row.column(align=True);options = row.column(align=True)
    try:fn = material_fn(material)
    except (ImportError, AttributeError):fn = None
    for kind, label, getter in [('TEX','Tex:','get_texture'),('SPA','Spa:','get_sphere_texture'),('TOON','Toon:','get_toon_texture')]:
        line = files.split(factor=.18, align=True);line.label(text=label)
        tex = getattr(fn, getter)() if fn else None
        image = getattr(tex, 'image', None)
        button = line.operator('clm_mmd.add_texture', text=bpy.path.basename(image.filepath) if image else '添加', icon='FILE_FOLDER')
        button.material_uid, button.object_uid, button.kind = material.session_uid, item.obj.session_uid, kind
    options.label(text='')
    options.prop(m, 'sphere_texture_type', text='Spa 模式')
    toon = options.row(align=True);toon.prop(m, 'is_shared_toon_texture', text='内置 toon')
    if m.is_shared_toon_texture:toon.prop(item, 'shared_toon', text='')
    texture.prop(m, 'comment', text='注释')


def draw_bone(layout, context, item, s, bone):
    m = bone.mmd_bone;draw_names(layout, s, m)
    row = layout.row(align=True);row.prop(m, 'transform_order', text='变形阶层');row.prop(m, 'transform_after_dynamics', text='物理后')
    row = layout.split(factor=.5, align=True);left = row.column(align=True);right = row.column(align=True)
    parent = left.row(align=True);parent.enabled = not item.obj.library and not item.obj.data.library
    parent.prop_search(item, 'parent_bone', item.obj.data, 'bones', text='亲骨骼')
    tail = left.box().column(align=True);tail.label(text='骨骼末端指向')
    buttons = tail.row(align=True)
    buttons.prop_enum(m, 'display_connection_type', 'BONE', text='骨骼')
    buttons.prop_enum(m, 'display_connection_type', 'OFFSET', text='相对')
    if m.display_connection_type == 'BONE':tail.prop_search(m, 'display_connection_bone', item.obj.pose, 'bones', text='骨骼')
    else:_vector_row(tail, item, 'tail_offset', '相对')
    extra = left.box().column(align=True)
    flags = extra.row(align=True);flags.label(text='付与');flags.prop(m, 'has_additional_rotation', text='旋转 +', toggle=True);flags.prop(m, 'has_additional_location', text='移动 +', toggle=True)
    extra.prop_search(m, 'additional_transform_bone', item.obj.pose, 'bones', text='付与亲')
    extra.prop(m, 'additional_transform_influence', text='付与率')
    axes = left.box().column(align=True);axes.prop(m, 'enabled_fixed_axis', text='轴限制')
    _vector_row(axes, m, 'fixed_axis', '轴向')
    axes.prop(m, 'enabled_local_axes', text='Local 轴')
    _vector_row(axes, m, 'local_axis_x', 'X')
    _vector_row(axes, m, 'local_axis_z', 'Z')
    flags = right.row(align=True)
    flags.prop(item, 'bone_rotate', text='旋转', toggle=True);flags.prop(item, 'bone_move', text='移动', toggle=True)
    ik_toggle = flags.row(align=True);ik_toggle.enabled = bool(_ik_matches(item));ik_toggle.prop(item, 'bone_ik', text='IK', toggle=True)
    flags.prop(item, 'bone_visible', text='显示', toggle=True);flags.prop(m, 'is_controllable', text='操作', toggle=True)
    ik = right.box().column(align=True);ik.label(text='IK')
    matches = _ik_matches(item)
    if not matches:ik.label(text='无 IK 约束')
    for owner, c in matches:
        ik.label(text=owner.name, icon='BONE_DATA')
        ik.prop(c, 'target', text='目标对象')
        if c.target and c.target.type == 'ARMATURE':ik.prop_search(c, 'subtarget', c.target.pose, 'bones', text='Target')
        else:ik.prop(c, 'subtarget', text='Target')
        params = ik.row(align=True);params.prop(c, 'iterations', text='Loop');params.prop(owner.mmd_bone, 'ik_rotation_constraint', text='单位角')
        ik.prop(c, 'chain_count', text='链长');ik.prop(c, 'use_tail', text='使用尾端')
        links = _ik_chain(owner, c)
        if links:
            selected = min(item.ik_link_index, len(links) - 1)
            editor = ik.split(factor=.36, align=True)
            names = editor.box().column(align=True);names.label(text='Link')
            for index, link in enumerate(links):
                button = names.operator('clm_mmd.select_ik_link', text=str(index) + ': ' + link.name, depress=index == selected)
                button.index, button.owner, button.constraint = index, owner.name, c.name
            link = links[selected]
            limits = editor.box().column(align=True);limits.label(text='角度限制 · ' + link.name)
            for axis in 'xyz':
                values = limits.split(factor=.14, align=True);values.prop(link, 'use_ik_limit_' + axis, text=axis.upper(), toggle=True)
                numeric = values.row(align=True);numeric.enabled = getattr(link, 'use_ik_limit_' + axis)
                numeric.prop(link, 'ik_min_' + axis, text='');numeric.prop(link, 'ik_max_' + axis, text='')
            footer = limits.row(align=True);footer.label(text='');footer.label(text='下限');footer.label(text='上限')
        else:
            ik.label(text='Link：无链节')
    row = layout.row(align=True);row.prop(m, 'is_tip', text='末端骨');row.prop(item.obj, 'show_in_front', text='骨骼透视')
    prop(layout, context.scene.tool_settings, 'use_auto_normalize', '权重自动归一化')


def comment_document(settings):
    """Edit the actual MMD Text datablock; never maintain a second text buffer."""
    root = settings.root
    if not root or root.library or root.mmd_root.id_data.library:
        return None
    field = 'comment_e_text' if settings.name_language == 'EN' else 'comment_text'
    other_field = 'comment_text' if settings.name_language == 'EN' else 'comment_e_text'
    name = getattr(root.mmd_root, field)
    text = bpy.data.texts.get(name)
    shared = text is not None and (text.library is not None or any(
        getattr(obj, 'mmd_type', '') == 'ROOT' and
        (obj != root and name in {obj.mmd_root.comment_text, obj.mmd_root.comment_e_text}
         or obj == root and name == getattr(obj.mmd_root, other_field))
        for obj in bpy.data.objects))
    if text is None or shared:
        contents = text.as_string() if text else ''
        text = bpy.data.texts.new(root.name + ('_简介_EN' if settings.name_language == 'EN' else '_简介'))
        text.write(contents)
        setattr(root.mmd_root, field, text.name)
    text.use_fake_user = True
    text['_clm_mmd_comment'] = True
    return text


def sync_comment_editor(window, settings, close=False):
    """Keep a small native multiline editor inside the workspace's upper right."""
    if bpy.app.background or not window.workspace.get(MARKER):
        return
    screen = window.screen
    if screen.as_pointer() in _comment_split_pending:
        return
    props = [a for a in screen.areas if a.type == 'PROPERTIES']
    if len(props) < 2:
        return
    manager = max(props, key=lambda a: (a.y, a.x))
    editors = [a for a in screen.areas if a.type == 'TEXT_EDITOR' and
               a.spaces.active.text and a.spaces.active.text.get('_clm_mmd_comment') and
               abs(a.x - manager.x) < 8 and abs(a.width - manager.width) < 8]
    document = comment_document(settings) if not close and settings.category == 'INFO' else None
    if document is None:
        for editor in editors:
            source = (editor.x + editor.width // 2, editor.y + editor.height // 2)
            target = (manager.x + manager.width // 2, manager.y + manager.height // 2)
            with bpy.context.temp_override(window=window, area=manager):
                bpy.ops.screen.area_join(source_xy=target, target_xy=source)
        return
    if not editors:
        before = {area.as_pointer() for area in screen.areas}
        with bpy.context.temp_override(window=window, area=manager):
            bpy.ops.screen.area_split(direction='HORIZONTAL', factor=.55)
        # Geometry is updated on the next redraw; identify the new area by identity.
        created = [area for area in screen.areas if area.as_pointer() not in before]
        if len(created) != 1:
            return
        pointers = {manager.as_pointer(), created[0].as_pointer()}
        token = screen.as_pointer()
        workspace = window.workspace
        _comment_split_pending.add(token)
        def initialize_comment():
            try:
                parts = [area for area in screen.areas if area.as_pointer() in pointers]
                active = window.workspace == workspace
            except ReferenceError:
                _comment_split_pending.discard(token)
                return None
            if not _registered or len(parts) != 2:
                _comment_split_pending.discard(token)
                return None
            if not active:
                return .1
            # Above 50%, Blender may retain the lower half as the original area.
            # Wait for layout, then always use the lower half as the editor.
            if parts[0].y == parts[1].y:
                return .1
            editor = min(parts, key=lambda area: area.y)
            editor.type = 'TEXT_EDITOR'
            if editor.spaces.active.type != 'TEXT_EDITOR':
                return .1
            editor.spaces.active.text = document
            _comment_needs_top.add(editor.as_pointer())
            workspace['clm_comment_layout_version'] = 383
            _comment_split_pending.discard(token)
            return None
        _pending_layout.append(initialize_comment)
        bpy.app.timers.register(initialize_comment, first_interval=.1)
        return
    if editors and window.workspace.get('clm_comment_layout_version') != 383:
        # Rebuild only our old divider; area_move needs an interactive mouse context.
        editor = editors[0]
        source = (manager.x + manager.width // 2, manager.y + manager.height // 2)
        target = (editor.x + editor.width // 2, editor.y + editor.height // 2)
        with bpy.context.temp_override(window=window, area=manager):
            bpy.ops.screen.area_join(source_xy=source, target_xy=target)
        return
    for editor in editors:
        space = editor.spaces.active
        if space.text != document or editor.as_pointer() in _comment_needs_top:
            space.text = document
            _comment_needs_top.discard(editor.as_pointer())
            with bpy.context.temp_override(window=window, area=editor):
                bpy.ops.text.move(type='FILE_TOP')
        space.show_word_wrap = True
        space.show_line_numbers = False
        space.show_syntax_highlight = False
        space.show_margin = False
        space.show_region_ui = False
        space.show_region_header = False
        if hasattr(space, 'show_region_footer'):
            space.show_region_footer = False
        editor.tag_redraw()


def draw_info(layout, context, s):
    root = s.root.mmd_root
    model = layout.box();model.label(text='模型', icon='OUTLINER_OB_ARMATURE')
    row = model.row(align=True)
    row.prop(root, 'name_e' if s.name_language == 'EN' else 'name', text='模型名')
    row.prop(s, 'name_language', expand=True)
    model.label(text='注释 · ' + ('英文' if s.name_language == 'EN' else '日文'), icon='TEXT')
    if s.root.library:
        model.label(text='链接模型的注释不可编辑', icon='LOCKED')



def draw_other(layout, context, item, s, target):
    if item.kind == 'MESH':
        layout.prop(target, 'name', text='对象名称')
        layout.label(text='网格数据：' + target.data.name, icon='MESH_DATA')
        if target.mode == 'EDIT':
            mesh = bmesh.from_edit_mesh(target.data)
            vertices, edges, faces = len(mesh.verts), len(mesh.edges), len(mesh.faces)
        else:
            vertices, edges, faces = len(target.data.vertices), len(target.data.edges), len(target.data.polygons)
        layout.label(text=f'顶点 {vertices} · 边 {edges} · 面 {faces}')
        layout.label(text=f'材质槽 {len(target.material_slots)} · 顶点组 {len(target.vertex_groups)}')
        layout.operator('clm_mmd.edit_item', text='视图编辑', icon='EDITMODE_HLT')
    elif item.kind == 'MATERIAL':
        draw_material(layout, context, item, s, target)
    elif item.kind == 'BONE':
        draw_bone(layout, context, item, s, target)
    elif item.kind == 'COLLECTION':
        draw_collection(layout, context, s, item.obj, target)
    elif item.kind == 'MORPH':
        if morph_editor.key(context) in morph_editor._sessions:
            layout.label(text='编辑操作与保存／取消在左侧')
            return
        kind,name=_morph_identity(item);meta=morph_api.metadata(s.root,kind,name)
        if kind=='vertex_morphs':
            owners=morph_meshes(s.root,name)
            box=layout.box()
            box.prop(s,'morph_show_meshes',text='关联网格（'+str(len(owners))+'）',icon='TRIA_DOWN' if s.morph_show_meshes else 'TRIA_RIGHT',emboss=False)
            if s.morph_show_meshes:
                for owner in owners:box.label(text=owner.name,icon='MESH_DATA')
        else:layout.label(text='所属模型：'+s.root.name,icon='OBJECT_DATA')
        layout.label(text='表情类型：'+dict((k,label) for k,label,_ in morph_editor.TYPES)[kind])
        layout.prop(item,'morph_name',text='名称')
        if meta:layout.prop(meta,'name_e',text='英文名')
        layout.prop(item,'morph_category',text='表情分类')
        row=layout.row(align=True)
        for category,label,_ in morph_api.CATEGORIES:
            row.operator('clm_mmd.morph_category',text=label).category=category
        layout.label(text='上方下拉编辑当前项；按钮应用到所选表情')
        morph_editor.draw_details(layout,context,item,target)


class CLM_MMD_PT_Manager(bpy.types.Panel):
    bl_idname = "CLM_MMD_PT_manager"
    bl_label = "PE · 大纲"
    bl_space_type = 'PROPERTIES'
    bl_region_type = 'WINDOW'
    bl_context = 'scene'
    bl_order = -100
    bl_options = {'HIDE_HEADER'}

    @classmethod
    def poll(cls, context):
        return manager_area(context)

    def draw(self, context):
        layout, s = self.layout, context.scene.clm_mmd_workspace
        layout.use_property_split = False
        layout.use_property_decorate = False
        row = layout.row(align=True)
        row.prop(s, 'root', text='模型')
        row.prop(s, 'lock_model', text='', icon='LOCKED' if s.lock_model else 'UNLOCKED', toggle=True)
        row.operator('clm_mmd.refresh', text='', icon='FILE_REFRESH')
        visibility = layout.row(align=True)
        visibility.label(text='可见性:')
        if s.root:
            root = s.root.mmd_root
            for name, label, icon in (
                ('show_meshes', '网格', 'MESH_DATA'),
                ('show_armature', '骨骼', 'BONE_DATA'),
                ('show_rigid_bodies', '刚体', 'RIGID_BODY'),
                ('show_joints', 'J点', 'CONSTRAINT'),
            ):
                visibility.prop(root, name, text=label, icon=icon, toggle=True)
        else:
            visibility.enabled = False
            for label in ('网格', '骨骼', '刚体', 'J点'):
                visibility.label(text=label)
        grid = layout.grid_flow(columns=4 if context.region.width < 460 else len(CATEGORIES), align=True)
        for category in CATEGORIES:
            grid.prop_enum(s, 'category', category[0], text=category[1])
        if not s.root:
            layout.label(text='请选择 MMD 模型根对象', icon='INFO')
            return
        if s.category == 'INFO':
            draw_info(layout, context, s)
            return
        split = layout.split(factor=s.list_fraction)
        left, right = split.column(), split.column(align=True)
        search = left.row(align=True)
        active_arm = armature_of(s.root, context.scene) if s.category == 'COLLECTION' else None
        if active_arm and context.view_layer.objects.active == active_arm:
            search.label(text='骨骼集合')
        else:
            search.prop(s, 'filter_text', text='', icon='VIEWZOOM')
        search.operator('clm_mmd.display_item', text='', icon='SOLO_OFF').action = 'RESET'
        if s.category == 'MORPH':
            filters=left.row(align=True)
            filters.prop(s,'morph_filter',text='分类')
            filters.prop(s,'morph_show_originals',text='',icon='HIDE_OFF' if s.morph_show_originals else 'HIDE_ON')
            morph_editor.draw_controls(left,context)
        if s.category == 'COLLECTION':
            arm = armature_of(s.root, context.scene)
            if arm and context.view_layer.objects.active == arm:
                # Scene Properties deliberately provides no context.object/armature.
                left.context_pointer_set('object', arm)
                left.context_pointer_set('active_object', arm)
                left.context_pointer_set('armature', arm.data)
                left.template_bone_collection_tree()
            else:
                left.template_list('CLM_MMD_UL_Items', '', s, 'items', s, 'index', rows=s.list_rows)
            controls = left.row(align=True)
            controls.enabled = bool(arm and arm.data.is_editable)
            for action, icon in [('ADD', 'ADD'), ('REMOVE', 'REMOVE'), ('UP', 'TRIA_UP'), ('DOWN', 'TRIA_DOWN')]:
                controls.operator('clm_mmd.collection_action', text='', icon=icon).action = action
            controls.operator('clm_mmd.collection_action', text='子集').action = 'ADD_CHILD'
        else:
            left.template_list('CLM_MMD_UL_Items', '', s, 'items', s, 'index', rows=s.list_rows)
        selected_count = len(checked_items(s))
        left.label(text='已选 ' + str(selected_count) + ' / ' + str(len(s.items)))
        actions = left.row(align=True)
        actions.operator('clm_mmd.select_all', text='全选').action = 'ALL'
        actions.operator('clm_mmd.select_all', text='清空').action = 'NONE'
        visibility = actions.row(align=True)
        visibility.enabled = s.category != 'MORPH'
        visibility.operator('clm_mmd.display_all', text='全显').visible = True
        visibility.operator('clm_mmd.display_all', text='全隐').visible = False
        item = current_item(s)
        target = item_target(item)
        if s.category=='MORPH' and morph_editor.key(context) in morph_editor._sessions:
            morph_editor.draw_session(right,context)
        elif target is None:
            right.label(text='此分类暂无可用条目', icon='INFO')
        else:
            if selected_count > 1:
                right.label(text='批量 ' + str(selected_count) + ' 项 · ≠ 多值 · 名称/关联仅当前项', icon='RESTRICT_SELECT_OFF')
            if s.batch_message:
                right.label(text=s.batch_message, icon='INFO')
            details = right.column(align=True) if item.kind == 'COLLECTION' else _BatchLayout(right.column(align=True), s, item)
            details.scale_y = 1.0
            details.enabled = (item.obj.data.is_editable and target.is_editable) if item.kind == 'COLLECTION' else selected_count > 0
            built = getattr(getattr(s.root, 'mmd_root', None), 'is_built', False)
            if built and s.category in {'RIGID', 'JOINT'}:
                right.label(text='先清理构建，再编辑参数', icon='LOCKED')
                details.enabled = False
            if item.kind == 'RIGID':
                draw_rigid(details, context, item, s)
            elif item.kind == 'JOINT':
                draw_joint(details, context, item, s)
            else:
                draw_other(details, context, item, s, target)
        layout.separator()
        row = layout.row(align=True)
        row.operator('clm_mmd.physics', text='构建物理', icon='PLAY').action = 'BUILD'
        row.operator('clm_mmd.physics', text='清理构建', icon='X').action = 'CLEAN'
        row.label(text='已构建' if s.root.mmd_root.is_built else '未构建')
        c = fold(layout, s, 'show_display', '列表设置')
        if c is not None:
            c.prop(s, 'list_fraction')
            c.prop(s, 'list_rows')


def _scroll_manager_top(window):
    if not _registered or not window.workspace.get(MARKER):
        return None
    props = [a for a in window.screen.areas if a.type == 'PROPERTIES']
    if len(props) < 2:
        return None
    area = max(props, key=lambda a: a.y)
    region = next((r for r in area.regions if r.type == 'WINDOW'), None)
    if region:
        with bpy.context.temp_override(window=window, area=area, region=region):
            for _ in range(12):
                bpy.ops.view2d.scroll_up(page=True)
    return None


class CLM_MMD_OT_OpenWorkspace(bpy.types.Operator):
    bl_idname = "clm_mmd.open_workspace"
    bl_label = "打开 PE 工作区"
    bl_description = "打开独立工作区：大视图、右上 PE 大纲、右下原生属性或草履虫绑定"
    def execute(self, context):
        if bpy.app.background or not context.window:
            self.report({'ERROR'}, '请在 Blender 界面中打开工作区')
            return {'CANCELLED'}
        existing = next((w for w in bpy.data.workspaces if w.get(MARKER)), None)
        if existing:
            existing.name = "PE"
            context.window.workspace = existing
            refresh(context)
            return {'FINISHED'}
        template = os.path.join(os.path.dirname(__file__), 'caolvchong_mmd_workspace.blend')
        if not os.path.isfile(template):
            self.report({'ERROR'}, '缺少工作区模板，请安装完整插件包')
            return {'CANCELLED'}
        window = context.window
        scene, view_layer = window.scene, window.view_layer
        original_view = next((a.spaces.active.region_3d for a in window.screen.areas if a.type == 'VIEW_3D'), None)
        view_state = {key: getattr(original_view, key).copy() if key in {'view_location', 'view_rotation'} else getattr(original_view, key)
                      for key in ('view_location', 'view_rotation', 'view_distance', 'view_perspective')} if original_view else {}
        before = {w.as_pointer() for w in bpy.data.workspaces}
        result = bpy.ops.workspace.append_activate(idname=WORKSPACE_NAME, filepath=template)
        if 'FINISHED' not in result:
            return {'CANCELLED'}
        workspace = next((w for w in bpy.data.workspaces if w.as_pointer() not in before), None)
        if workspace is None:
            self.report({'ERROR'}, '工作区追加失败')
            return {'CANCELLED'}
        workspace.name = "PE"
        workspace[MARKER] = True
        # Workspace activation is deferred by Blender until the next UI event.
        # Touching window.screen here would modify the user's ORIGINAL workspace.
        def initialize(attempt=[0]):
            if not _registered:
                return None
            if window.workspace != workspace:
                attempt[0] += 1
                return .1 if attempt[0] < 20 else None
            window.scene = scene
            window.view_layer = view_layer
            for area in window.screen.areas:
                if area.type == 'OUTLINER':
                    area.type = 'PROPERTIES'
                    space = area.spaces.active
                    space.context = 'SCENE'
                    space.use_pin_id = False
                    space.show_region_header = False
                    for prop_def in space.bl_rna.properties:
                        if prop_def.identifier.startswith('show_properties_'):
                            setattr(space, prop_def.identifier, prop_def.identifier == 'show_properties_scene')
                elif area.type == 'VIEW_3D':
                    area.spaces.active.show_region_ui = False
                    area.spaces.active.shading.type = 'SOLID'
                    for key, value in view_state.items():
                        setattr(area.spaces.active.region_3d, key, value)
            with bpy.context.temp_override(window=window):
                refresh(bpy.context)
                sync_material_preview(bpy.context, bpy.context.scene.clm_mmd_workspace)
            arm = armature_of(scene.clm_mmd_workspace.root, scene)
            if arm:
                arm.show_in_front = True
            callback = lambda: _scroll_manager_top(window)
            _pending_layout.append(callback)
            bpy.app.timers.register(callback, first_interval=.3)
            return None
        _pending_layout.append(initialize)
        bpy.app.timers.register(initialize, first_interval=.1)
        return {'FINISHED'}


def _watch():
    if not _registered:
        return None
    _install_material_export_guards()
    _properties_router().refresh()
    for mesh in bpy.data.meshes:
        if not mesh.is_editmode and _has_material_edit_ownership(mesh):_restore_material_edit(mesh)
    for window in bpy.context.window_manager.windows:
        if window.workspace.get(MARKER):
            with bpy.context.temp_override(window=window):
                settings = bpy.context.scene.clm_mmd_workspace
                before = tuple((i.name, i.key) for i in settings.items)
                refresh(bpy.context)
                sync_material_preview(bpy.context, bpy.context.scene.clm_mmd_workspace)
                changed = sync_list_selection(bpy.context, settings)
                changed = changed or before != tuple((i.name, i.key) for i in settings.items)
                sync_comment_editor(window, settings)
            for area in window.screen.areas:
                if area.type == 'PROPERTIES':
                    with bpy.context.temp_override(window=window, area=area):
                        if binding_area(bpy.context):
                            if area.spaces.active.context != 'SCENE':area.spaces.active.context = 'SCENE'
            if changed:
                for area in window.screen.areas:
                    if area.type == 'PROPERTIES':area.tag_redraw()
    return .2


class CLM_MMD_OT_MorphCategory(bpy.types.Operator):
    bl_idname='clm_mmd.morph_category'
    bl_label='批量设置表情分类'
    bl_options={'REGISTER','UNDO'}
    category:EnumProperty(items=morph_api.CATEGORIES)
    def execute(self,context):
        s=context.scene.clm_mmd_workspace
        try:
            targets={}
            for item in checked_items(s):
                kind,name=_morph_identity(item);targets.setdefault(kind,set()).add(name)
            if not targets:raise ValueError('请先选择表情')
            for kind,names in targets.items():morph_api.assign_category(s.root,kind,names,self.category)
            self.report({'INFO'},'已设置所选表情分类');return {'FINISHED'}
        except (ValueError,RuntimeError) as exc:self.report({'ERROR'},str(exc));return {'CANCELLED'}

CLASSES = (CLM_MMD_OT_MorphCategory, CLM_MMD_CollectionMember, CLM_MMD_OT_CollectionAction, CLM_MMD_OT_CollectionMemberSelect, CLM_MMD_UL_CollectionMembers, CLM_MMD_Item, CLM_MMD_DisplayMember, CLM_MMD_DisplayGroup, CLM_MMD_BatchValues, CLM_MMD_Settings, CLM_MMD_UL_Items, CLM_MMD_OT_SelectItem, CLM_MMD_OT_SelectAll, CLM_MMD_OT_DisplayAll, CLM_MMD_OT_DisplayItem, CLM_MMD_OT_Refresh,
           CLM_MMD_OT_EditItem, CLM_MMD_OT_SelectIKLink, CLM_MMD_OT_AddTexture, CLM_MMD_OT_Physics, CLM_MMD_PT_Manager, CLM_MMD_OT_OpenWorkspace)


CLASSES=(CLM_MMD_OT_AlignPhysicsBone,)+CLASSES


def register():
    global _registered
    if _registered:
        return
    for cls in CLASSES:
        bpy.utils.register_class(cls)
    bpy.types.Scene.clm_mmd_workspace = PointerProperty(type=CLM_MMD_Settings)
    morph_editor.register(sys.modules[__name__])
    _registered = True
    _properties_router().attach('PE',manager_area,lambda c:False)
    _schedule_pe_workspace()
    if _pe_load_post not in bpy.app.handlers.load_post:bpy.app.handlers.load_post.append(_pe_load_post)
    _properties_router().refresh()
    _install_material_export_guards()
    if not bpy.app.background:
        bpy.app.timers.register(_watch, first_interval=.2, persistent=True)


def unregister():
    global _registered
    morph_editor.unregister()
    for window in bpy.context.window_manager.windows:
        if window.workspace.get(MARKER):
            for area in window.screen.areas:
                if area.type == 'PROPERTIES':
                    with bpy.context.temp_override(window=window, area=area):
                        if binding_area(bpy.context):set_binding_page(bpy.context, 'NATIVE')
    _properties_router().detach('PE')
    if _pe_load_post in bpy.app.handlers.load_post:bpy.app.handlers.load_post.remove(_pe_load_post)
    for cls, name, descriptor, wrapper in reversed(_binding_operator_methods):
        if cls.__dict__.get(name) is wrapper:setattr(cls, name, descriptor)
    _binding_operator_methods.clear()
    for space, native_context, pinned, pin_id, flags in list(_binding_states.values()):
        try:
            space.pin_id = pin_id
            space.use_pin_id = pinned
            for name, value in flags.items():setattr(space, name, value)
            try:space.context = native_context
            except (TypeError, ValueError):space.context = 'SCENE'
        except ReferenceError:pass
    for workspace in bpy.data.workspaces:
        if workspace.get(MARKER):workspace['clm_binding_page'] = 'NATIVE'
    _binding_states.clear()
    _registered = False
    for callback in [_watch] + _pending_layout:
        if bpy.app.timers.is_registered(callback):
            bpy.app.timers.unregister(callback)
    _pending_layout.clear()
    _comment_split_pending.clear()
    _comment_needs_top.clear()
    _native_selections.clear()
    if not bpy.app.background and hasattr(bpy.types.Scene, 'clm_mmd_workspace'):
        for window in bpy.context.window_manager.windows:
            sync_comment_editor(window, window.scene.clm_mmd_workspace, close=True)
    if hasattr(bpy.types.Scene, 'clm_mmd_workspace'):
        for scene in getattr(bpy.data, 'scenes', []):
            for group in scene.clm_mmd_workspace.display_groups:
                if not group.solos:continue
                layer = _group_layer(scene, group) if group.view_layer else scene.view_layers[0]
                if layer:
                    with bpy.context.temp_override(scene=scene, view_layer=layer):
                        _restore_display(group, bpy.context)
        _sync_material_edit_cleanup()
        for obj in getattr(bpy.data, 'objects', []):_remove_material_preview(obj)
        del bpy.types.Scene.clm_mmd_workspace
    for module, original, wrapped in _material_export_guards:
        if module.export is wrapped:module.export = original
    _material_export_guards.clear()
    pass  # Shared router owns native panel restoration.
    for cls in reversed(CLASSES):
        bpy.utils.unregister_class(cls)

def _properties_router():
    import sys, importlib.util
    name='caolvchong_properties_router'
    if name not in sys.modules:
        spec=importlib.util.spec_from_file_location(name,os.path.join(os.path.dirname(__file__),name+'.py'))
        module=importlib.util.module_from_spec(spec);sys.modules[name]=module;spec.loader.exec_module(module)
    return sys.modules[name]

def _draw_pe_menu(self,context):
    self.layout.operator("clm_mmd.open_workspace",text="打开 PE 工作区",icon="WORKSPACE")


def _schedule_pe_workspace():
    if bpy.app.background:return
    def ensure():
        if not _registered:return None
        existing=next((w for w in bpy.data.workspaces if w.get(MARKER)),None)
        if existing:
            existing.name='PE'
            return None
        window=next(iter(bpy.context.window_manager.windows),None)
        if not window:return .2
        previous=window.workspace
        with bpy.context.temp_override(window=window):
            result=bpy.ops.clm_mmd.open_workspace()
        if result!={'FINISHED'}:return None
        target=next((w for w in bpy.data.workspaces if w.get(MARKER)),None)
        if target is None:return None
        def restore(attempt=[0]):
            if not _registered:return None
            attempt[0]+=1
            try:
                if window.workspace==target and len([a for a in window.screen.areas if a.type=='PROPERTIES'])>=2:
                    if previous in list(bpy.data.workspaces):window.workspace=previous
                    return None
            except ReferenceError:return None
            return .1 if attempt[0]<30 else None
        _pending_layout.append(restore);bpy.app.timers.register(restore,first_interval=.2)
        return None
    _pending_layout.append(ensure);bpy.app.timers.register(ensure,first_interval=.3)

@bpy.app.handlers.persistent
def _pe_load_post(_):
    if _registered:_schedule_pe_workspace()
