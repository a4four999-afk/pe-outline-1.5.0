import bpy
_registered=True
_scene_panel_filters=[]
_owners={}
def manager_area(context):
    return any(callbacks[0](context) for callbacks in tuple(_owners.values()))
def binding_area(context):
    return any(callbacks[1](context) for callbacks in tuple(_owners.values()))
def _scene_panels():
    pending, result, seen = list(bpy.types.Panel.__subclasses__()), [], set()
    while pending:
        cls = pending.pop(0)
        if cls in seen:
            continue
        seen.add(cls);pending.extend(cls.__subclasses__())
        if (getattr(cls, 'bl_space_type', '') == 'PROPERTIES' and
                getattr(cls, 'is_registered', False) and cls.__name__ not in {'CLM_MMD_PT_Manager', 'CLM_MMD_PT_Binding', 'WANG_BIND_PT_Binding'}):
            result.append(cls)
    ordered, remaining = [], list(result)
    ids = {getattr(cls, 'bl_idname', cls.__name__) or cls.__name__: cls for cls in result}
    while remaining:
        ready = [cls for cls in remaining if ids.get(getattr(cls, 'bl_parent_id', '')) not in remaining]
        if not ready:
            ready = [remaining[0]]
        ordered.extend(ready)
        for cls in ready:remaining.remove(cls)
    return ordered


def _filter_scene_panels():
    known = {entry[0] for entry in _scene_panel_filters}
    panels = [cls for cls in _scene_panels() if cls not in known]
    if not panels:
        return
    entries = [(cls, cls.__dict__.get('poll'), getattr(cls, 'poll', None)) for cls in panels]
    for cls in reversed(panels):bpy.utils.unregister_class(cls)
    for cls, descriptor, original in entries:
        def make_poll(original):
            def poll(cls, context):
                if _registered and ((manager_area(context) and getattr(cls, "bl_context", "") == "scene") or binding_area(context)):
                    return False
                return original(context) if original else True
            return classmethod(poll)
        wrapper = make_poll(original)
        cls.poll = wrapper
        bpy.utils.register_class(cls)
        _scene_panel_filters.append((cls, descriptor, wrapper))


def _restore_scene_panels():
    entries = list(_scene_panel_filters)
    live = {cls for cls, _, _ in entries if getattr(cls, 'is_registered', False)}
    for cls, descriptor, wrapper in reversed(entries):
        if cls in live:bpy.utils.unregister_class(cls)
    for cls, descriptor, wrapper in entries:
        if cls.__dict__.get('poll') is wrapper:
            if descriptor is None:delattr(cls, 'poll')
            else:cls.poll = descriptor
        if cls in live:bpy.utils.register_class(cls)
    _scene_panel_filters.clear()



def attach(key, manager, binding):
    _owners[key]=(manager,binding)
    _filter_scene_panels()
def detach(key):
    _owners.pop(key,None)
    if not _owners:_restore_scene_panels()
def refresh():
    if _owners:_filter_scene_panels()
