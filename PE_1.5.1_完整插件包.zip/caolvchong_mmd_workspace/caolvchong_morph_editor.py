"""PE morph authoring. Source offsets use mmd_tools; previews are reversible."""
import importlib
import math
from collections import namedtuple
import bpy
import numpy as np
from mathutils import Matrix, Quaternion, Vector
from bpy.props import BoolProperty, EnumProperty, FloatProperty, PointerProperty, StringProperty, IntProperty

TYPES = [('vertex_morphs','顶点',''), ('material_morphs','材质',''),
         ('uv_morphs','UV',''), ('bone_morphs','骨骼',''), ('group_morphs','组合','')]
_sessions = {}
_previews = {}
_pe = None


def tools():
    # Works with both legacy add-ons and Blender extension package names.
    for name, module in tuple(__import__('sys').modules.items()):
        if name.endswith('mmd_tools.core.morph') and hasattr(module, 'FnMorph'):
            return module.FnMorph
    return importlib.import_module('mmd_tools.core.morph').FnMorph


def state(context):
    return context.scene.clm_mmd_workspace, context.scene.clm_pe_morph


def key(context): return context.scene.as_pointer()


def selected(context):
    s, e = state(context)
    item = _pe.current_item(s)
    if not s.root or not item or item.kind != 'MORPH':
        raise ValueError('请先选择一个表情')
    target = _pe.item_target(item)
    if target is None: raise ValueError('表情已被删除，请刷新列表')
    kind, name = _pe._morph_identity(item)
    return s.root, kind, name, item.obj, target


def editable(root):
    if root.library and not root.override_library: raise ValueError('链接模型不能直接编辑')
    if root.mmd_root.is_built: raise ValueError('请先清理物理构建，再编辑表情')
    if any(o.mmd_type == 'PLACEHOLDER' and o.type == 'MESH' and o.data.shape_keys
           and not o.data.shape_keys.key_blocks[0].mute for o in root.children):
        raise ValueError('请先在 mmd_tools 中解除表情绑定，再使用 PE 编辑／预览')


def choose_mesh(context, root, preferred=None,shape_name=None):
    s, e = state(context)
    meshes = _pe.morph_meshes(root,shape_name) if shape_name is not None else _pe.morph_api.meshes(root)
    for obj in (e.mesh, context.view_layer.objects.active, preferred):
        if obj in meshes: return obj
    if len(meshes) == 1: return meshes[0]
    raise ValueError('请在“目标网格”中选择当前模型的网格')


def activate(context, obj, mode='OBJECT'):
    active = context.view_layer.objects.active
    if active and active.mode != 'OBJECT': bpy.ops.object.mode_set(mode='OBJECT')
    if obj.name not in context.view_layer.objects: raise ValueError('目标对象不在当前视图层')
    obj.hide_set(False)
    for other in context.view_layer.objects:
        if other.select_get(): other.select_set(False)
    obj.select_set(True)
    context.view_layer.objects.active = obj
    if mode != 'OBJECT': bpy.ops.object.mode_set(mode=mode)


def dump(pg):
    result = {}
    for p in pg.bl_rna.properties:
        n = p.identifier
        if n == 'rna_type': continue
        v = getattr(pg, n)
        if p.type == 'COLLECTION': result[n] = [dump(x) for x in v]
        elif not p.is_readonly: result[n] = tuple(v) if getattr(p,'is_array',False) else v
    return result


def load(pg, values):
    for n, v in values.items():
        if pg.bl_rna.properties[n].type == 'COLLECTION':
            collection = getattr(pg, n); collection.clear()
            for entry in v: load(collection.add(), entry)
        else: setattr(pg, n, v)


def topology(mesh):
    return (len(mesh.vertices),tuple(tuple(e.vertices) for e in mesh.edges),
            tuple(tuple(p.vertices) for p in mesh.polygons))


def capture(root):
    meshes = _pe.morph_api.meshes(root)
    arm = _pe.armature_of(root, bpy.context.scene)
    return dict(root=root, shader_nodes=[], shader_links=[], identity=None,
        bones=[(b, b.matrix_basis.copy()) for b in arm.pose.bones] if arm else [],
        shapes=[(k, k.value) for o in meshes for k in getattr(o.data.shape_keys,'key_blocks',[])],
        uvs=[(o.data, uv.name, [x.uv.copy() for x in uv.data]) for o in meshes for uv in o.data.uv_layers],
        materials=[(mat.mmd_material, {n: tuple(getattr(mat.mmd_material,n)) if hasattr(getattr(mat.mmd_material,n),'__len__') else getattr(mat.mmd_material,n)
                    for n in ('diffuse_color','alpha','specular_color','shininess','ambient_color','edge_color','edge_weight')})
                   for mat in {m for o in meshes for m in o.data.materials if m}])


def restore(snapshot):
    for tree,names in snapshot['shader_nodes']:
        for name in names:
            node=tree.nodes.get(name)
            if node: tree.nodes.remove(node)
    for tree,links in snapshot['shader_links']:
        for source,dest in links:
            tree.links.new(source,dest)
    snapshot['shader_nodes'].clear(); snapshot['shader_links'].clear()
    for b, matrix in snapshot['bones']: b.matrix_basis = matrix
    for shape, value in snapshot['shapes']: shape.value = value
    for mesh, name, coords in snapshot['uvs']:
        uv = mesh.uv_layers.get(name)
        if uv is None: raise ValueError('原始 UV 层已被删除：'+name)
        if len(uv.data) != len(coords): raise ValueError('网格拓扑已变化，无法恢复 UV')
        for x, co in zip(uv.data, coords): x.uv = co
    for mesh,name,base,offset in snapshot.get('uv_arrays',[]):
        layer=mesh.uv_layers.get(name)
        if layer and len(layer.data)*2==base.size:
            layer.data.foreach_set('uv',base.ravel())
    for mat, values in snapshot['materials']:
        for n, value in values.items(): setattr(mat, n, value)


def expand(root, kind, name, weight=1., stack=()):
    identity = (kind, name)
    if identity in stack: raise ValueError('组合表情存在循环引用：'+name)
    if kind == 'vertex_morphs': return [(kind, name, weight)]
    morph = _pe.morph_api.metadata(root, kind, name)
    if morph is None: raise ValueError('表情引用不存在：'+name)
    if kind != 'group_morphs': return [(kind, name, weight)]
    result = []
    for d in morph.data:
        result.extend(expand(root, d.morph_type, d.name, weight*d.factor, stack+(identity,)))
    return result


def apply_preview(root, kind, name, weight, snapshot=None):
    leaves = expand(root, kind, name, weight)
    meshes = _pe.morph_api.meshes(root)
    arm = _pe.armature_of(root, bpy.context.scene)
    shader_offsets={}
    for kind, name, value in leaves:
        if kind == 'vertex_morphs':
            for obj in meshes:
                shape = obj.data.shape_keys.key_blocks.get(name) if obj.data.shape_keys else None
                if shape: shape.value += value
        elif kind == 'bone_morphs':
            if arm is None: raise ValueError('模型没有骨架')
            for d in root.mmd_root.bone_morphs[name].data:
                bone = arm.pose.bones.get(d.bone)
                if bone:
                    q = Quaternion(d.rotation)
                    rotation = Quaternion().slerp(q, value)
                    matrix = bone.matrix_basis.copy()
                    new = matrix.to_3x3().to_4x4() @ rotation.to_matrix().to_4x4()
                    new.translation = matrix.translation + Vector(d.location)*value
                    bone.matrix_basis = new
        elif kind == 'uv_morphs':
            morph = root.mmd_root.uv_morphs[name]
            for obj in meshes:
                layers = [uv for uv in obj.data.uv_layers if not uv.name.startswith('_')]
                offsets = tools().get_uv_morph_offset_map(obj, morph)
                if not offsets: continue
                if morph.uv_index >= len(layers): raise ValueError('表情指定的 UV 层不存在')
                for loop, d in zip(obj.data.loops, layers[morph.uv_index].data):
                    offset = offsets.get(loop.vertex_index)
                    if offset: d.uv += Vector(offset[:2])*value
        elif kind == 'material_morphs':
            for d in root.mmd_root.material_morphs[name].data:
                mats = {m for o in meshes for m in o.data.materials if m and (not d.material or m.name == d.material)}
                for mat in mats:
                    tree=mat.node_tree
                    if snapshot is not None and tree and tree.nodes.get('mmd_shader'):
                        shader_offsets.setdefault(mat,[]).append((d,value))
                        continue
                    mm = mat.mmd_material
                    for n in ('diffuse_color','specular_color','ambient_color','edge_color','shininess','edge_weight'):
                        old, offset = getattr(mm,n), getattr(d,n)
                        if hasattr(old,'__len__'):
                            vals = offset[:len(old)]
                            setattr(mm,n, [a+b*value if d.offset_type=='ADD' else a*(1+(b-1)*value) for a,b in zip(old,vals)])
                        else: setattr(mm,n,old+offset*value if d.offset_type=='ADD' else old*(1+(offset-1)*value))
                    alpha = d.diffuse_color[3]
                    mm.alpha = mm.alpha+alpha*value if d.offset_type=='ADD' else mm.alpha*(1+(alpha-1)*value)
    if shader_offsets:
        shader_module=importlib.import_module(tools().__module__.rsplit('.',1)[0]+'.shader')
        for mat,offsets in shader_offsets.items():
            tree=mat.node_tree
            previous={node.name for node in tree.nodes}
            links=[(link.from_socket,link.to_socket) for link in tree.links]
            # PMX applies multiplicative offsets before additive offsets.
            offsets.sort(key=lambda pair:pair[0].offset_type!='MULT')
            snapshot['shader_links'].append((tree,links))
            try:
                nodes=shader_module._MaterialMorph.setup_morph_nodes(mat,[d for d,v in offsets])
                for node,(d,value) in zip(nodes,offsets): node.inputs[0].default_value=value
            finally:
                snapshot['shader_nodes'].append((tree,[n.name for n in tree.nodes if n.name not in previous]))


def zero(context):
    snap = _previews.pop(key(context), None)
    if snap:
        try: restore(snap)
        except ReferenceError: pass
    context.scene.clm_pe_morph['preview'] = 0.


def prepare_preview(root,kind,name):
    """Compile only the affected channels, once per continuous preview."""
    leaves=expand(root,kind,name)
    meshes=_pe.morph_api.meshes(root)
    arm=_pe.armature_of(root,bpy.context.scene)
    snap=dict(root=root,identity=(kind,name),bones=[],shapes=[],uvs=[],materials=[],
              shader_nodes=[],shader_links=[],shape_targets={},bone_ops=[],uv_arrays=[],
              shader_factors=[],material_ops=[])
    # Isolation needs shape values, but never needs unrelated geometry or UVs.
    for obj in meshes:
        for shape in getattr(obj.data.shape_keys,'key_blocks',[]):
            snap['shapes'].append((shape,shape.value))
    bones={}; uv_offsets={}; material_offsets={}
    for morph_kind,morph_name,factor in leaves:
        if morph_kind=='vertex_morphs':
            seen_shapes=set()
            for obj in meshes:
                shape=obj.data.shape_keys.key_blocks.get(morph_name) if obj.data.shape_keys else None
                if shape and shape.as_pointer() not in seen_shapes:
                    seen_shapes.add(shape.as_pointer())
                    snap['shape_targets'][shape]=snap['shape_targets'].get(shape,0.)+factor
        elif morph_kind=='bone_morphs':
            if arm is None: raise ValueError('模型没有骨架')
            for d in root.mmd_root.bone_morphs[morph_name].data:
                bone=arm.pose.bones.get(d.bone)
                if bone:
                    bones.setdefault(bone,bone.matrix_basis.copy())
                    snap['bone_ops'].append((bone,Vector(d.location),Quaternion(d.rotation),factor))
        elif morph_kind=='uv_morphs':
            morph=root.mmd_root.uv_morphs[morph_name]
            for obj in meshes:
                offsets=tools().get_uv_morph_offset_map(obj,morph)
                if not offsets: continue
                layers=[uv for uv in obj.data.uv_layers if not uv.name.startswith('_')]
                if morph.uv_index>=len(layers): raise ValueError('表情指定的 UV 层不存在')
                layer=layers[morph.uv_index]
                identity=(obj.data,layer.name)
                if identity not in uv_offsets:
                    uv_offsets[identity]=np.zeros((len(obj.data.vertices),2),dtype=np.float32)
                values=uv_offsets[identity]
                for index,offset in offsets.items():
                    if index<0 or index>=len(values): raise ValueError('UV 表情引用的顶点不存在')
                    values[index]+=np.asarray(offset[:2],dtype=np.float32)*factor
        elif morph_kind=='material_morphs':
            for d in root.mmd_root.material_morphs[morph_name].data:
                for mat in {m for o in meshes for m in o.data.materials if m and (not d.material or m.name==d.material)}:
                    material_offsets.setdefault(mat,[]).append((d,factor))
    snap['bones']=list(bones.items())
    for (mesh,layer_name),offsets in uv_offsets.items():
        layer=mesh.uv_layers[layer_name]
        base=np.empty(len(mesh.loops)*2,dtype=np.float32)
        layer.data.foreach_get('uv',base)
        indices=np.empty(len(mesh.loops),dtype=np.int32)
        mesh.loops.foreach_get('vertex_index',indices)
        snap['uv_arrays'].append((mesh,layer_name,base.reshape((-1,2)),offsets[indices]))
    # Register the snapshot before changing graph links, so errors can roll back.
    _previews[key(bpy.context)]=snap
    try:
        for mat,offsets in material_offsets.items():
            tree=mat.node_tree
            offsets.sort(key=lambda pair:pair[0].offset_type!='MULT')
            if tree and tree.nodes.get('mmd_shader'):
                shader_module=importlib.import_module(tools().__module__.rsplit('.',1)[0]+'.shader')
                previous={node.name for node in tree.nodes}
                snap['shader_links'].append((tree,[(l.from_socket,l.to_socket) for l in tree.links]))
                try:
                    nodes=shader_module._MaterialMorph.setup_morph_nodes(mat,[d for d,f in offsets])
                    snap['shader_factors'].extend((node.inputs[0],factor) for node,(d,factor) in zip(nodes,offsets))
                finally:
                    snap['shader_nodes'].append((tree,[n.name for n in tree.nodes if n.name not in previous]))
            else:
                mm=mat.mmd_material
                fields=('diffuse_color','alpha','specular_color','shininess','ambient_color','edge_color','edge_weight')
                baseline={n:tuple(getattr(mm,n)) if hasattr(getattr(mm,n),'__len__') else getattr(mm,n) for n in fields}
                snap['materials'].append((mm,baseline))
                snap['material_ops'].extend((mm,d,factor) for d,factor in offsets)
        for shape,value in snap['shapes']:
            if value!=0: shape.value=0.
    except Exception:
        restore(snap); _previews.pop(key(bpy.context),None); raise
    return snap


def update_preview(snap,value):
    # No model scans, UV snapshots, graph changes or forced depsgraph evaluations.
    for shape,factor in snap['shape_targets'].items(): shape.value=value*factor
    for bone,matrix in snap['bones']: bone.matrix_basis=matrix
    for bone,location,rotation,factor in snap['bone_ops']:
        weight=value*factor
        matrix=bone.matrix_basis.copy()
        new=matrix.to_3x3().to_4x4() @ Quaternion().slerp(rotation,weight).to_matrix().to_4x4()
        new.translation=matrix.translation+location*weight
        bone.matrix_basis=new
    for mesh,name,base,offset in snap['uv_arrays']:
        layer=mesh.uv_layers.get(name)
        if layer is None or len(layer.data)*2!=base.size: raise ValueError('预览期间 UV 层或拓扑发生变化，请归零')
        layer.data.foreach_set('uv',(base+offset*value).ravel())
    for socket,factor in snap['shader_factors']: socket.default_value=value*factor
    for mm,baseline in snap['materials']:
        for n,v in baseline.items(): setattr(mm,n,v)
    for mm,d,factor in snap['material_ops']:
        weight=value*factor
        for n in ('diffuse_color','specular_color','ambient_color','edge_color','shininess','edge_weight'):
            old,offset=getattr(mm,n),getattr(d,n)
            if hasattr(old,'__len__'):
                setattr(mm,n,[a+b*weight if d.offset_type=='ADD' else a*(1+(b-1)*weight) for a,b in zip(old,offset)])
            else: setattr(mm,n,old+offset*weight if d.offset_type=='ADD' else old*(1+(offset-1)*weight))
        alpha=d.diffuse_color[3]
        mm.alpha=mm.alpha+alpha*weight if d.offset_type=='ADD' else mm.alpha*(1+(alpha-1)*weight)


def preview_update(e, context):
    e.message = ''
    if key(context) in _sessions: return
    try:
        value = e.preview
        if value == 0:
            zero(context); return
        root, kind, name, obj, target = selected(context)
        snap=_previews.get(key(context))
        if snap is None or snap['root']!=root or snap['identity']!=(kind,name):
            zero(context); editable(root)
            snap=prepare_preview(root,kind,name)
            _previews[key(context)]=snap
        try:
            update_preview(snap,value)
        except Exception:
            zero(context); raise
        e['preview'] = value
    except (ValueError, RuntimeError, ReferenceError) as exc: e.message = str(exc)


def start(context):
    if key(context) in _sessions: raise ValueError('请先保存或取消当前编辑')
    active=context.view_layer.objects.active
    if active and active.mode=='EDIT' and active.type=='MESH': active.update_from_editmode()
    root, kind, name, obj, target = selected(context)
    editable(root); zero(context)
    s, e = state(context)
    mesh = choose_mesh(context,root,obj,shape_name=name if kind=='vertex_morphs' else None) if kind in {'vertex_morphs','uv_morphs'} else None
    if kind=='vertex_morphs':
        obj=mesh;target=mesh.data.shape_keys.key_blocks[name]
    if kind == 'uv_morphs' and target.uv_index >= len([u for u in mesh.data.uv_layers if not u.name.startswith('_')]):
        raise ValueError('目标网格没有对应的 UV 层，请先建立 UV')
    snap = capture(root)
    session = dict(root=root, kind=kind, name=name, obj=obj, target=target,
                   source=None if kind=='vertex_morphs' else dump(target), snapshot=snap,
                   mesh=mesh, temp_uv=None, shape_coords=None,
                   active=context.view_layer.objects.active,
                   selection=[o for o in context.view_layer.objects if o.select_get()],
                   mode=context.view_layer.objects.active.mode if context.view_layer.objects.active else 'OBJECT')
    session['mesh_backup']=mesh.data.copy() if mesh else None
    session['topology']=topology(mesh.data) if mesh else None
    _sessions[key(context)] = session
    try:
        if kind == 'vertex_morphs':
            session['shape_coords'] = [x.co.copy() for x in target.data]
            session['shape_index'] = obj.active_shape_key_index
            session['show_only'] = obj.show_only_shape_key
            activate(context,obj)
            obj.active_shape_key_index = obj.data.shape_keys.key_blocks.find(name)
            obj.show_only_shape_key = True; target.value = 1
            bpy.ops.object.mode_set(mode='EDIT')
        elif kind == 'bone_morphs':
            arm = _pe.armature_of(root,context.scene)
            if arm is None: raise ValueError('模型没有骨架')
            activate(context,arm,'POSE')
            for b in arm.pose.bones: b.matrix_basis = Matrix.Identity(4)
            apply_preview(root,kind,name,1.)
        elif kind == 'uv_morphs':
            activate(context,mesh)
            layers = [u for u in mesh.data.uv_layers if not u.name.startswith('_')]
            base = layers[target.uv_index]
            session['base_uv'] = base.name; session['uv_active'] = mesh.data.uv_layers.active_index
            session['uv_render'] = [u.name for u in mesh.data.uv_layers if u.active_render]
            coords = [x.uv.copy() for x in base.data]
            temp = mesh.data.uv_layers.new(name='__pe_morph_edit__')
            session['temp_uv'] = temp.name
            offsets = tools().get_uv_morph_offset_map(mesh,target)
            for loop, d, co in zip(mesh.data.loops,temp.data,coords):
                d.uv = co + Vector(offsets.get(loop.vertex_index,(0,0,0,0))[:2])
            mesh.data.uv_layers.active = temp; temp.active_render = True
            bpy.ops.object.mode_set(mode='EDIT'); bpy.ops.mesh.select_all(action='SELECT')
            session['uv_areas']=[]
            if context.screen:
                existing=next((a for a in context.screen.areas if a.type=='IMAGE_EDITOR'),None)
                area=existing or next((a for a in context.screen.areas if a.type=='VIEW_3D'),None)
                if area:
                    if not existing: session['uv_areas'].append((area,area.type))
                    area.type='IMAGE_EDITOR'; area.ui_type='UV'
        e.message = ''
    except Exception:
        finish(context,False)
        raise


def save_uv(session):
    mesh, morph = session['mesh'], session['target']
    temp, base = mesh.data.uv_layers[session['temp_uv']], mesh.data.uv_layers[session['base_uv']]
    offsets = {}
    for loop, a, b in zip(mesh.data.loops,temp.data,base.data):
        delta = a.uv-b.uv
        if loop.vertex_index in offsets and (offsets[loop.vertex_index]-delta).length > 1e-4:
            raise ValueError('同一顶点的 UV 接缝偏移不同，PMX 无法表示；请让接缝两侧移动相同距离')
        offsets[loop.vertex_index] = delta
    if morph.data_type != 'VERTEX_GROUP' and len(_pe.morph_api.meshes(session['root'])) > 1 and morph.data:
        raise ValueError('旧式 UV 偏移涉及多个网格，请先在 mmd_tools 转换为顶点组格式')
    Entry = namedtuple('UVOffset','index offset')
    values = [Entry(i,(v.x,v.y,0,0)) for i,v in offsets.items() if v.length > 1e-5]
    # XY is authored here; preserve existing ZW offsets.
    old = tools().get_uv_morph_offset_map(mesh,morph)
    for entry in values:
        if entry.index in old: old[entry.index] = (entry.offset[0],entry.offset[1],*old[entry.index][2:])
        else: old[entry.index] = entry.offset
    for i in list(old):
        if i not in {entry.index for entry in values}: old[i] = (0,0,*old[i][2:])
    all_offsets={obj:tools().get_uv_morph_offset_map(obj,morph) for obj in _pe.morph_api.meshes(session['root'])}
    all_offsets[mesh]=old
    # The scale belongs to the morph, whereas weights live on each mesh.
    # Pick the final scale first, then rewrite all meshes against that scale.
    final_scale=max([abs(morph.vertex_group_scale)]+[abs(v) for offsets in all_offsets.values() for values in offsets.values() for v in values])
    morph.data.clear(); morph.data_type = 'VERTEX_GROUP'; morph.vertex_group_scale=final_scale
    for obj,offsets in all_offsets.items():
        tools().store_uv_morph_data(obj,morph,[Entry(i,v) for i,v in offsets.items()])


def finish(context, save):
    session = _sessions.get(key(context))
    if session is None: raise ValueError('当前没有正在编辑的表情')
    s, e = state(context)
    active = context.view_layer.objects.active
    if active and active.mode != 'OBJECT': bpy.ops.object.mode_set(mode='OBJECT')
    kind, target = session['kind'], session['target']
    mesh=session['mesh']; backup=session['mesh_backup']
    topology_changed=mesh is not None and topology(mesh.data)!=session['topology']
    if save and topology_changed:
        raise ValueError('表情编辑不能改变网格拓扑；请取消以恢复网格，再单独修改拓扑')
    if not save and topology_changed:
        damaged=mesh.data
        old_keys=damaged.shape_keys
        session['snapshot']['uvs']=[entry for entry in session['snapshot']['uvs'] if entry[0]!=damaged]
        session['snapshot']['shapes']=[entry for entry in session['snapshot']['shapes'] if entry[0].id_data!=old_keys]
        for owner in bpy.data.objects:
            if owner.type=='MESH' and owner.data==damaged: owner.data=backup
        target=mesh.data.shape_keys.key_blocks[session['name']] if kind=='vertex_morphs' else target
        session['target']=target
        session['temp_uv']=None
        session['mesh_backup']=None
    if save:
        if kind == 'bone_morphs':
            arm = _pe.armature_of(session['root'],context.scene)
            values = [(b.name,tuple(b.location),tuple(b.matrix_basis.to_quaternion())) for b in arm.pose.bones
                      if b.location.length > 1e-7 or b.matrix_basis.to_quaternion().angle > 1e-7]
            target.data.clear()
            for name, loc, rot in values:
                d = target.data.add(); d.bone=name; d.location=loc; d.rotation=rot
        elif kind == 'uv_morphs': save_uv(session)
        elif kind == 'group_morphs': expand(session['root'],kind,session['name'])
    else:
        if kind == 'vertex_morphs':
            if len(target.data) != len(session['shape_coords']): raise ValueError('拓扑已变化，请使用 Blender 撤销恢复')
            for x, co in zip(target.data,session['shape_coords']): x.co=co
        else: load(target, session['source'])
    if session['temp_uv']:
        mesh = session['mesh']; mesh.data.uv_layers.remove(mesh.data.uv_layers[session['temp_uv']])
        mesh.data.uv_layers.active_index = session['uv_active']
        for uv in mesh.data.uv_layers: uv.active_render = uv.name in session['uv_render']
    restore(session['snapshot'])
    if kind=='uv_morphs' and not topology_changed:
        # The UV editor must not inadvertently save geometry movement.
        for v,original in zip(mesh.data.vertices,backup.vertices): v.co=original.co
    if kind == 'vertex_morphs':
        session['obj'].active_shape_key_index = session['shape_index']
        session['obj'].show_only_shape_key = session['show_only']
    _sessions.pop(key(context),None)
    for area,original_type in session.get('uv_areas',[]):
        try: area.type=original_type
        except ReferenceError: pass
    if session['mesh_backup'] and session['mesh_backup'].users==0:
        bpy.data.meshes.remove(session['mesh_backup'])
    for o in context.view_layer.objects: o.select_set(o in session['selection'])
    if session['active'] and session['active'].name in context.view_layer.objects:
        context.view_layer.objects.active=session['active']
        if session['mode'] != 'OBJECT': bpy.ops.object.mode_set(mode=session['mode'])
    # Checked children may move the list cursor while editing a group.
    # Return the cursor to the expression whose Save/Cancel was clicked.
    _pe._selection_edit = True
    try:
        for n,item in enumerate(s.items):
            if tuple(_pe._morph_identity(item)) == (kind,session['name']):
                s.index = n
                break
    finally: _pe._selection_edit = False
    e.message='已保存表情' if save else '已取消，恢复编辑前状态'
    context.view_layer.update()


class PE_MorphSettings(bpy.types.PropertyGroup):
    mesh: PointerProperty(name='目标网格',type=bpy.types.Object,poll=lambda s,o:o.type=='MESH' and getattr(o,'mmd_type','NONE')=='NONE')
    material: PointerProperty(name='目标材质',type=bpy.types.Material)
    preview: FloatProperty(name='预览值',min=0,max=1,update=preview_update)
    message: StringProperty()
    advanced: BoolProperty(name='更多材质参数',default=False)
    attach_kind: EnumProperty(name='来源类型',items=TYPES,default='bone_morphs')
    attach_name: StringProperty(name='来源表情')
    attach_strength: FloatProperty(name='强度',default=1.,soft_min=0,soft_max=1)


def attach_plan(root,source,targets):
    """Resolve names and validate the resulting graph before touching the model."""
    if source[0]=='vertex_morphs':
        exists=any(o.data.shape_keys and source[1] in o.data.shape_keys.key_blocks for o in _pe.morph_api.meshes(root))
    else: exists=_pe.morph_api.metadata(root,*source) is not None
    if not exists: raise ValueError('来源表情不存在，请重新选择')
    expand(root,*source)
    identities=list(dict.fromkeys(tuple(_pe._morph_identity(i)) for i in targets))
    identities=[identity for identity in identities if identity!=source]
    if not identities: raise ValueError('请勾选要附加到的目标表情，来源自身不会被修改')
    if len({name for kind,name in identities})!=len(identities):
        raise ValueError('所选目标含不同类型的同名表情，请先重命名以避免组合名称冲突')
    used={m.name for kind,_,_ in TYPES for m in getattr(root.mmd_root,kind)}
    used.update(k.name for o in _pe.morph_api.meshes(root) for k in getattr(o.data.shape_keys,'key_blocks',[]))
    used.update(name for kind,name in identities)
    plans=[]; mapping={}
    for identity in identities:
        kind,name=identity
        if kind=='group_morphs':
            expand(root,kind,name)
            plans.append((kind,name,None,None));continue
        if name in root.mmd_root.group_morphs:
            raise ValueError('已存在同名组合表情：'+name+'；请先重命名')
        base=name+'__原始';index=1
        while base in used:
            base=f'{name}__原始.{index:03d}';index+=1
        used.add(base)
        item=next(i for i in targets if tuple(_pe._morph_identity(i))==identity)
        plans.append((kind,name,base,_pe._morph_category(item)))
        mapping[identity]=('group_morphs',name)
    graph={('group_morphs',g.name):[mapping.get((d.morph_type,d.name),(d.morph_type,d.name)) for d in g.data]
           for g in root.mmd_root.group_morphs}
    for kind,name,base,category in plans:
        identity=('group_morphs',name)
        if base is not None: graph[identity]=[(kind,base)]
        if source not in graph[identity]: graph[identity].append(source)
    visited=set();visiting=set()
    def visit(identity):
        if identity in visiting: raise ValueError('附加后会产生循环引用：'+identity[1])
        if identity in visited: return
        visiting.add(identity)
        for child in graph.get(identity,[]): visit(child)
        visiting.remove(identity);visited.add(identity)
    for identity in graph: visit(identity)
    return plans,mapping


def attach_morphs(root,source,targets,strength):
    if not math.isfinite(strength): raise ValueError('附加强度必须为有限数值')
    plans,mapping=attach_plan(root,source,targets)
    groups_before={g.name:dump(g) for g in root.mmd_root.group_morphs}
    display_before=[(frame_index,index,d.morph_type,d.name)
                    for frame_index,frame in enumerate(root.mmd_root.display_item_frames)
                    for index,d in enumerate(frame.data) if d.type=='MORPH']
    caches=[(o.data,{k:dict(v) for k,v in o.data.get('clm_morph_categories',{}).items()}
             if 'clm_morph_categories' in o.data else None) for o in _pe.morph_api.meshes(root)]
    renamed=[];created=[]
    try:
        for kind,name,base,category in plans:
            if base is None: continue
            meta=_pe.morph_api.metadata(root,kind,name)
            was_missing=meta is None
            if was_missing: meta=_pe.morph_api.metadata(root,kind,name,True)
            record=dict(kind=kind,name=name,base=base,missing=was_missing,
                        category=meta.category,flag=meta.get('clm_attach_original'))
            renamed.append(record)
            english=meta.name_e
            meta.name=base
            if meta.name!=base: raise ValueError('原始表情重命名冲突：'+name)
            meta.category='SYSTEM';meta['clm_attach_original']=True
            if kind=='vertex_morphs':
                for obj in _pe.morph_api.meshes(root):
                    if obj.data.shape_keys and base in obj.data.shape_keys.key_blocks:
                        values={k:dict(v) for k,v in obj.data.get('clm_morph_categories',{}).items()}
                        values.pop(name,None)
                        values[base]={'category':'SYSTEM','source':'MANUAL'}
                        obj.data['clm_morph_categories']=values
            group=root.mmd_root.group_morphs.add();group.name=name;created.append(group.name)
            if group.name!=name: raise ValueError('组合表情命名冲突：'+name)
            group.name_e=english;group.category=category
            child=group.data.add();child.morph_type=kind;child.name=base;child.factor=1.
        # Native renaming updates old references to the hidden base. Route the
        # pre-existing references to the public wrapper; never rewrite its base.
        for group_name,values in groups_before.items():
            group=root.mmd_root.group_morphs[group_name]
            for index,old in enumerate(values['data']):
                mapped=mapping.get((old['morph_type'],old['name']))
                if mapped:
                    group.data[index].morph_type,group.data[index].name=mapped
        for frame_index,index,kind,name in display_before:
            mapped=mapping.get((kind,name))
            if mapped:
                d=root.mmd_root.display_item_frames[frame_index].data[index]
                d.morph_type,d.name=mapped
        for kind,name,base,category in plans:
            group=root.mmd_root.group_morphs[name]
            matches=[i for i,d in enumerate(group.data) if (d.morph_type,d.name)==source]
            if matches:
                group.data[matches[0]].factor=strength
                for index in reversed(matches[1:]):group.data.remove(index)
            else:
                child=group.data.add();child.morph_type,child.name=source;child.factor=strength
        for kind,name,base,category in plans: expand(root,'group_morphs',name)
    except Exception:
        # Roll back only affected metadata; retain the source object and data.
        for name in reversed(created):
            index=root.mmd_root.group_morphs.find(name)
            if index>=0:root.mmd_root.group_morphs.remove(index)
        for record in reversed(renamed):
            collection=getattr(root.mmd_root,record['kind'])
            meta=collection.get(record['base']) or collection.get(record['name'])
            if meta is not None:
                meta.name=record['name'];meta.category=record['category']
                if record['flag'] is None:
                    if 'clm_attach_original' in meta:del meta['clm_attach_original']
                else:meta['clm_attach_original']=record['flag']
                if record['missing']:collection.remove(collection.find(record['name']))
        for name,values in groups_before.items():load(root.mmd_root.group_morphs[name],values)
        for frame_index,index,kind,name in display_before:
            d=root.mmd_root.display_item_frames[frame_index].data[index];d.morph_type=kind;d.name=name
        for mesh,values in caches:
            if values is None:
                if 'clm_morph_categories' in mesh:del mesh['clm_morph_categories']
            else:mesh['clm_morph_categories']=values
        raise
    return {('group_morphs',name) for kind,name,base,category in plans}


class PE_OT_MorphAttach(bpy.types.Operator):
    bl_idname='clm_mmd.morph_attach'
    bl_label='批量附加表情'
    bl_description='给勾选表情附加另一个表情；保留目标名称，来源自身保持不变'
    bl_options={'REGISTER','UNDO'}
    source_kind: EnumProperty(name='来源类型',items=TYPES,default='bone_morphs')
    source_name: StringProperty(name='来源表情')
    strength: FloatProperty(name='附加强度',default=1.,soft_min=0,soft_max=1)

    def invoke(self,context,event):
        s,e=state(context)
        self.source_kind=e.attach_kind;self.source_name=e.attach_name;self.strength=e.attach_strength
        return context.window_manager.invoke_props_dialog(self,width=420)

    def draw(self,context):
        s,e=state(context);layout=self.layout
        layout.prop(self,'source_kind')
        if s.root:layout.prop_search(self,'source_name',s.root.mmd_root,self.source_kind,text='来源表情')
        layout.prop(self,'strength')
        targets=list(dict.fromkeys(tuple(_pe._morph_identity(i)) for i in _pe.checked_items(s)))
        layout.label(text='目标：左侧勾选的 '+str(sum(t!=(self.source_kind,self.source_name) for t in targets))+' 个表情')
        for kind,name in targets[:6]:
            if (kind,name)!=(self.source_kind,self.source_name):layout.label(text=name,icon='SHAPEKEY_DATA')
        layout.label(text='保留目标名称；原始数据移入隐藏分类')
        layout.label(text='已有相同来源时更新强度，不重复添加')

    def execute(self,context):
        try:
            s,e=state(context)
            if key(context) in _sessions:raise ValueError('请先保存或取消当前编辑')
            if not s.root:raise ValueError('请先选择 MMD 模型')
            editable(s.root);zero(context)
            targets=_pe.checked_items(s)
            wrapped=attach_morphs(s.root,(self.source_kind,self.source_name),targets,self.strength)
            e.attach_kind=self.source_kind;e.attach_name=self.source_name;e.attach_strength=self.strength
            _pe.refresh(context)
            _pe._selection_edit=True
            try:
                first=None
                for n,item in enumerate(s.items):
                    item.selected=tuple(_pe._morph_identity(item)) in wrapped
                    if item.selected and first is None:first=n
                if first is not None:s.index=first
            finally:_pe._selection_edit=False
            e.message='已为 '+str(len(wrapped))+' 个表情附加“'+self.source_name+'”'
            self.report({'INFO'},e.message)
            return {'FINISHED'}
        except (ValueError,RuntimeError,ReferenceError,TypeError) as exc:
            self.report({'ERROR'},str(exc));return {'CANCELLED'}


class PE_OT_MorphCreate(bpy.types.Operator):
    bl_idname='clm_mmd.morph_create'
    bl_label='新建表情'
    bl_options={'REGISTER','UNDO'}
    kind: EnumProperty(name='类型',items=TYPES)
    name: StringProperty(name='名称',default='新表情')

    def invoke(self,context,event): return context.window_manager.invoke_props_dialog(self)
    def execute(self,context):
        try:
            s,e=state(context)
            if key(context) in _sessions: raise ValueError('请先保存或取消当前编辑')
            if not s.root: raise ValueError('请先选择 MMD 模型')
            editable(s.root); zero(context)
            name=self.name.strip()
            if not name: raise ValueError('表情名称不能为空')
            used={m.name for kind,_,_ in TYPES for m in getattr(s.root.mmd_root,kind)}
            used.update(k.name for o in _pe.morph_api.meshes(s.root) for k in getattr(o.data.shape_keys,'key_blocks',[]))
            base=name; index=1
            while name in used: name=f'{base}.{index:03d}'; index+=1
            mesh=choose_mesh(context,s.root) if self.kind=='vertex_morphs' else None
            if mesh:
                if not mesh.data.shape_keys: mesh.shape_key_add(name='Basis')
                mesh.shape_key_add(name=name,from_mix=False).value=0.
            target=_pe.morph_api.metadata(s.root,self.kind,name,True)
            target.category='OTHER'
            if self.kind=='uv_morphs': target.data_type='VERTEX_GROUP'
            s.category='MORPH'; s.filter_text=''; s.morph_filter='ALL'; _pe.refresh(context)
            for n,item in enumerate(s.items):
                item.selected=False
                if tuple(_pe._morph_identity(item))==(self.kind,name): s.index=n; item.selected=True
            return {'FINISHED'}
        except (ValueError,RuntimeError) as exc:
            self.report({'ERROR'},str(exc)); return {'CANCELLED'}


class PE_OT_MorphAction(bpy.types.Operator):
    bl_idname='clm_mmd.morph_action'
    bl_label='表情操作'
    bl_options={'REGISTER','UNDO'}
    action: EnumProperty(items=[(x,x,'') for x in ('EDIT','SAVE','CANCEL','ZERO','SOLO','ADD_OFFSET','REMOVE_OFFSET','ADD_CHECKED')])
    index: IntProperty(default=-1)

    def execute(self,context):
        try:
            s,e=state(context)
            if self.action=='EDIT': start(context)
            elif self.action in {'SAVE','CANCEL'}: finish(context,self.action=='SAVE')
            elif self.action=='ZERO':
                if key(context) in _sessions: raise ValueError('请先保存或取消当前编辑')
                zero(context)
            elif self.action=='SOLO':
                zero(context); e.preview=1.
                if e.message: raise ValueError(e.message)
            else:
                session=_sessions.get(key(context))
                if not session: raise ValueError('请先开始编辑')
                kind,target=session['kind'],session['target']
                if self.action=='ADD_OFFSET' and kind=='material_morphs':
                    mats={m for o in _pe.morph_api.meshes(session['root']) for m in o.data.materials if m}
                    if e.material not in mats: raise ValueError('请选择当前模型使用的材质')
                    d=target.data.add(); d.material=e.material.name; d.offset_type='ADD'
                    d.diffuse_color=(0,0,0,0)
                    d.related_mesh=next(o.data.name for o in _pe.morph_api.meshes(session['root']) if e.material.name in o.data.materials)
                elif self.action=='REMOVE_OFFSET':
                    if self.index < 0 or self.index >= len(target.data): raise ValueError('偏移已不存在')
                    target.data.remove(self.index)
                elif self.action=='ADD_CHECKED' and kind=='group_morphs':
                    entries=[]
                    for item in _pe.checked_items(s):
                        identity=tuple(_pe._morph_identity(item))
                        if identity==(kind,session['name']): continue
                        # Validate before mutating, including transitive group cycles.
                        expand(session['root'],*identity,stack=((kind,session['name']),))
                        if not any(d.morph_type==identity[0] and d.name==identity[1] for d in target.data): entries.append(identity)
                    if not entries: raise ValueError('请在左侧勾选要加入的其他表情')
                    for entry_kind,name in dict.fromkeys(entries):
                        d=target.data.add(); d.morph_type=entry_kind; d.name=name; d.factor=1.
                else: raise ValueError('当前表情不支持此操作')
            return {'FINISHED'}
        except (ValueError,RuntimeError,ReferenceError) as exc:
            self.report({'ERROR'},str(exc)); return {'CANCELLED'}


def draw_controls(layout,context):
    s,e=state(context)
    row=layout.row(align=True); row.enabled=key(context) not in _sessions
    row.operator_menu_enum('clm_mmd.morph_create','kind',text='新建表情',icon='ADD')
    row.operator('clm_mmd.morph_action',text='归零').action='ZERO'
    row=layout.row(align=True);row.enabled=key(context) not in _sessions
    row.operator('clm_mmd.morph_attach',text='批量附加表情',icon='ADD')
    layout.prop(e,'mesh',text='编辑网格')
    if e.message: layout.label(text=e.message,icon='INFO')


def draw_session(layout,context):
    session=_sessions[key(context)]
    box=layout.box(); box.label(text='正在编辑：'+session['name'],icon='EDITMODE_HLT')
    row=box.row(align=True)
    row.operator('clm_mmd.morph_action',text='保存',icon='CHECKMARK').action='SAVE'
    row.operator('clm_mmd.morph_action',text='取消',icon='X').action='CANCEL'
    draw_edit(box,context,session)


def draw_details(layout,context,item,target):
    if key(context) in _sessions: return
    s,e=state(context)
    layout.operator('clm_mmd.morph_action',text='开始编辑',icon='EDITMODE_HLT').action='EDIT'
    layout.prop(e,'preview',text='预览值',slider=True)
    row=layout.row(align=True)
    row.operator('clm_mmd.morph_action',text='单独预览').action='SOLO'
    row.operator('clm_mmd.morph_action',text='归零').action='ZERO'


def scope_changed(context):
    snap=_previews.get(key(context))
    if snap is not None:
        try:
            root,kind,name,obj,target=selected(context)
            if root==snap['root'] and (kind,name)==snap['identity']: return
        except (ValueError,ReferenceError): pass
        zero(context)


def draw_edit(layout,context,session):
    kind,target=session['kind'],session['target']
    e=context.scene.clm_pe_morph
    if kind=='vertex_morphs': layout.label(text='在三维视图移动顶点，完成后保存')
    elif kind=='bone_morphs': layout.label(text='在姿态模式摆出表情，完成后保存')
    elif kind=='uv_morphs': layout.label(text='在 UV 编辑器修改临时 UV，完成后保存')
    elif kind=='material_morphs':
        layout.prop(e,'material',text='目标材质')
        layout.operator('clm_mmd.morph_action',text='添加材质偏移',icon='ADD').action='ADD_OFFSET'
        for n,d in enumerate(target.data):
            box=layout.box(); row=box.row(align=True)
            row.label(text=d.material or '全部材质')
            op=row.operator('clm_mmd.morph_action',text='',icon='X'); op.action='REMOVE_OFFSET'; op.index=n
            box.prop(d,'offset_type',text='计算方式')
            box.prop(d,'diffuse_color',text='颜色 / 透明度')
            box.prop(e,'advanced',text='更多材质参数',icon='TRIA_DOWN' if e.advanced else 'TRIA_RIGHT',emboss=False)
            if not e.advanced: continue
            for field,label in [('specular_color','高光'),('shininess','高光强度'),('ambient_color','环境色'),('edge_color','描边颜色'),('edge_weight','描边宽度'),('texture_factor','贴图系数'),('sphere_texture_factor','球面贴图系数'),('toon_texture_factor','Toon 系数')]:
                box.prop(d,field,text=label)
    elif kind=='group_morphs':
        layout.label(text='勾选左侧表情，再点击添加；权重可逐项调整')
        layout.operator('clm_mmd.morph_action',text='添加勾选表情',icon='ADD').action='ADD_CHECKED'
        for n,d in enumerate(target.data):
            row=layout.row(align=True); row.label(text=d.name); row.prop(d,'factor',text='权重')
            op=row.operator('clm_mmd.morph_action',text='',icon='X'); op.action='REMOVE_OFFSET'; op.index=n


def cleanup():
    for scene in bpy.data.scenes:
        with bpy.context.temp_override(scene=scene):
            try:
                if scene.as_pointer() in _sessions: finish(bpy.context,False)
                zero(bpy.context)
            except (ReferenceError,RuntimeError,ValueError): pass
    _sessions.clear(); _previews.clear()


@bpy.app.handlers.persistent
def before_load(_): cleanup()


@bpy.app.handlers.persistent
def before_save(_):
    # Never serialize temporary UVs or shader links into the user's .blend.
    for scene in bpy.data.scenes:
        with bpy.context.temp_override(scene=scene):
            if scene.as_pointer() in _sessions:
                try: finish(bpy.context,True)
                except (ValueError,RuntimeError) as exc:
                    # Handler exceptions do not abort Blender's file save.
                    # Roll back invalid edits before the file is serialized.
                    finish(bpy.context,False)
                    scene.clm_pe_morph.message='文件已保存；无效表情编辑已恢复：'+str(exc)
            zero(bpy.context)


@bpy.app.handlers.persistent
def before_undo(_): cleanup()


def register(pe):
    global _pe
    _pe=pe
    for cls in (PE_MorphSettings,PE_OT_MorphCreate,PE_OT_MorphAction,PE_OT_MorphAttach): bpy.utils.register_class(cls)
    bpy.types.Scene.clm_pe_morph=PointerProperty(type=PE_MorphSettings)
    if before_load not in bpy.app.handlers.load_pre: bpy.app.handlers.load_pre.append(before_load)
    if before_save not in bpy.app.handlers.save_pre: bpy.app.handlers.save_pre.append(before_save)
    if before_undo not in bpy.app.handlers.undo_pre: bpy.app.handlers.undo_pre.append(before_undo)
    if before_undo not in bpy.app.handlers.redo_pre: bpy.app.handlers.redo_pre.append(before_undo)


def unregister():
    cleanup()
    if before_load in bpy.app.handlers.load_pre: bpy.app.handlers.load_pre.remove(before_load)
    if before_save in bpy.app.handlers.save_pre: bpy.app.handlers.save_pre.remove(before_save)
    if before_undo in bpy.app.handlers.undo_pre: bpy.app.handlers.undo_pre.remove(before_undo)
    if before_undo in bpy.app.handlers.redo_pre: bpy.app.handlers.redo_pre.remove(before_undo)
    if hasattr(bpy.types.Scene,'clm_pe_morph'): del bpy.types.Scene.clm_pe_morph
    for cls in (PE_OT_MorphAttach,PE_OT_MorphAction,PE_OT_MorphCreate,PE_MorphSettings): bpy.utils.unregister_class(cls)
