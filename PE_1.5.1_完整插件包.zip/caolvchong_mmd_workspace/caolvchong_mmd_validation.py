"""Shared PMX checks and native MMD morph categories; no add-on registration."""
import math
import os
import re
import importlib
from pathlib import Path
import bpy
from contextlib import contextmanager

CATEGORIES=[('EYEBROW','眉',''),('EYE','眼',''),('MOUTH','口',''),('OTHER','其他',''),('SYSTEM','隐藏','')]
MORPH_TYPES=('vertex_morphs','bone_morphs','material_morphs','uv_morphs','group_morphs')
ALIASES={
 'EYEBROW':{'困る','怒り','にこり','上','下','真面目','眉上','眉下','眉怒','眉困'},
 'EYE':{'まばたき','笑い','ウィンク','ウィンク右','ウィンク２','ウィンク２右','なごみ','じと目','ジト目','びっくり','悲しむ','怒り目'},
 'MOUTH':{'あ','い','う','え','お','ん','ワ','ω','にやり','口角上げ','口角下げ','ぺろっ','歯無し','あ２','い２','う２','え２','お２'},
}

def model_root(obj):
    while obj:
        if getattr(obj,'mmd_type','')=='ROOT':return obj
        obj=obj.parent
    return None

def meshes(root):
    return [o for o in root.children_recursive if o.type=='MESH' and getattr(o,'mmd_type','NONE')=='NONE']

def guess_category(name):
    value=re.sub(r'(?:[._ -](?:l|r|left|right)|左|右)$','',name.casefold()).strip()
    for category,names in ALIASES.items():
        if value in {n.casefold() for n in names}:return category
    for category,words in [('EYEBROW',('眉','brow','eyebrow')),('MOUTH',('口','嘴','唇','舌','牙','mouth','lip','tongue','jaw')),('EYE',('眼','目','まばたき','ウィンク','blink','wink','eye','瞳','なごみ','じと'))]:
        if any(word in value for word in words):return category
    return 'OTHER'

def metadata(root,kind,name,create=False):
    values=getattr(root.mmd_root,kind)
    found=values.get(name)
    if found is None and create:
        found=values.add();found.name=name
    return found

def shape_category(obj,name):
    saved=obj.data.get('clm_morph_categories',{}).get(name)
    return dict(saved) if saved else None

def store_shape_category(obj,name,category,source='AUTO'):
    saved={k:dict(v) for k,v in obj.data.get('clm_morph_categories',{}).items()}
    saved[name]={'category':category,'source':source};obj.data['clm_morph_categories']=saved

def assign_category(root,kind,names,category):
    if category not in {c[0] for c in CATEGORIES}:raise ValueError('无效表情分类')
    if root.library and not root.override_library:raise ValueError('链接模型不能直接修改分类')
    for name in set(names):
        morph=metadata(root,kind,name,True);morph.category=category;morph['clm_category_source']='MANUAL'
        if kind=='vertex_morphs':
            for obj in meshes(root):
                if obj.data.shape_keys and name in obj.data.shape_keys.key_blocks:store_shape_category(obj,name,category,'MANUAL')

def classify_missing(root):
    sources={}
    for obj in meshes(root):
        keys=obj.data.shape_keys
        if keys:
            for key in keys.key_blocks:
                if key==keys.reference_key:continue
                sources.setdefault(key.name,[]).append(obj)
    changed=[];unknown=[];plan=[]
    for name,objects in sources.items():
        morph=metadata(root,'vertex_morphs',name)
        # Existing imported or manually configured MMD categories always win.
        if morph is not None and morph.get('clm_category_source')!='AUTO':continue
        if morph is not None and 'clm_category_last_auto' in morph and morph.category!=morph['clm_category_last_auto']:continue
        saved=[shape_category(obj,name) for obj in objects];saved=[v for v in saved if v]
        categories={v['category'] for v in saved}
        if len(categories)>1:raise ValueError('同名表情分类冲突：'+name)
        category=next(iter(categories)) if categories else guess_category(name)
        plan.append((name,category,saved))
    for name,category,saved in plan:
        morph=metadata(root,'vertex_morphs',name,True)
        if morph.category!=category or not morph.get('clm_category_source'):changed.append(name)
        morph.category=category;morph['clm_category_source']='MANUAL' if any(v.get('source')=='MANUAL' for v in saved) else 'AUTO'
        morph['clm_category_last_auto']=category
        if category=='OTHER' and not saved:unknown.append(name)
    return {'changed':changed,'unknown':unknown}

@contextmanager
def classification_transaction(root):
    values=root.mmd_root.vertex_morphs
    snapshot={m.name:(m.category,m.get('clm_category_source'),m.get('clm_category_last_auto')) for m in values}
    try:yield
    except Exception:
        for i in reversed(range(len(values))):
            if values[i].name not in snapshot:values.remove(i)
        for m in values:
            category,source,last=snapshot[m.name];m.category=category
            for key,value in [('clm_category_source',source),('clm_category_last_auto',last)]:
                if value is None:
                    if key in m:del m[key]
                else:m[key]=value
        raise

def check_model(root,scale=12.5,filepath=None):
    issues=[]
    def add(severity,code,message,obj=None,key=''):
        issues.append({'severity':severity,'code':code,'message':message,'object':obj.name if obj else '', 'key':key})
    if root is None or getattr(root,'mmd_type','')!='ROOT':
        add('ERROR','MODEL','请选择 MMD 模型或其骨架');return report(issues)
    children=list(root.children_recursive);mesh_objects=meshes(root);arms=[o for o in children if o.type=='ARMATURE']
    arm=arms[0] if arms else None
    exported={root,*mesh_objects,*arms,*(o for o in children if getattr(o,'mmd_type','') in {'RIGID_BODY','JOINT'})}
    for obj in tuple(exported):
        parent=obj.parent
        while parent:
            exported.add(parent);parent=parent.parent
    for obj in exported:
        rotation=obj.rotation_quaternion if obj.rotation_mode=='QUATERNION' else obj.rotation_axis_angle if obj.rotation_mode=='AXIS_ANGLE' else obj.rotation_euler
        values=[*obj.location,*obj.scale,*rotation,*(x for row in obj.matrix_world for x in row)]
        if any(not math.isfinite(x) for x in values):add('ERROR','OBJECT_FINITE','对象变换包含无效数值：'+obj.name,obj)
    if arm is None:add('ERROR','ARMATURE','模型没有骨架',root)
    elif not arm.data.bones:add('ERROR','BONES','骨架没有骨骼',arm)
    if len(arms)>1:add('WARNING','ARMATURE_MULTIPLE','模型包含多个骨架，请确认导出目标',root)
    if not math.isfinite(scale) or scale<=0:add('ERROR','SCALE','导出倍率必须为有限正数',root)
    if root.mmd_root.is_built:add('ERROR','BUILT','请先清理物理构建，再导出静止模型',root)
    if not mesh_objects:add('ERROR','MESH','模型没有可导出的网格',root)
    if not root.mmd_root.name:add('WARNING','NAME','模型名称为空',root)
    if not getattr(root.mmd_root,'comment_text',''):add('WARNING','COMMENT','模型注释为空',root)
    if filepath:
        target=Path(bpy.path.abspath(filepath))
        if target.exists() and target.is_dir():add('ERROR','PATH','导出目标是文件夹',root)
        parent=target.parent
        while not parent.exists() and parent.parent!=parent:parent=parent.parent
        if not parent.is_dir() or not os.access(parent,os.W_OK):add('ERROR','PATH','导出路径不可写',root)
    bone_names=set(arm.data.bones.keys()) if arm else set();deform={b.name for b in arm.data.bones if b.use_deform} if arm else set()
    if arm:
        names={}
        for bone in arm.pose.bones:
            label=bone.mmd_bone.name_j or bone.name
            names.setdefault(label,[]).append(bone.name)
            if not all(math.isfinite(x) for x in (*bone.bone.head_local,*bone.bone.tail_local)):add('ERROR','BONE_FINITE','骨骼坐标无效：'+bone.name,arm,bone.name)
            elif bone.bone.length<1e-8:add('WARNING','BONE_LENGTH','零长度骨骼：'+bone.name,arm,bone.name)
        for label,values in names.items():
            if len(values)>1:add('WARNING','BONE_NAME','骨骼日文名重复：'+label,arm,values[0])
    morph_names={};shape_names=set();material_names=set();materials=set()
    for obj in mesh_objects:
        if not obj.data.polygons:add('WARNING','MESH_EMPTY','网格没有面',obj)
        if any(not all(math.isfinite(c) for c in vert.co) for vert in obj.data.vertices):add('ERROR','VERTEX_FINITE','网格存在无效坐标',obj)
        valid={g.index for g in obj.vertex_groups if g.name in deform};unbound=unnormal=0;used=set();bad_weight=False
        for vert in obj.data.vertices:
            used.update(g.group for g in vert.groups if g.weight>0)
            bad_weight=bad_weight or any(not math.isfinite(g.weight) or g.weight<0 for g in vert.groups)
            weight=sum(g.weight for g in vert.groups if g.group in valid)
            if weight<1e-7:unbound+=1
            elif abs(weight-1.)>.001:unnormal+=1
        if unbound:add('WARNING','UNBOUND',f'{unbound} 个顶点没有有效骨骼权重',obj)
        if unnormal:add('WARNING','WEIGHT_SUM',f'{unnormal} 个顶点权重未归一化',obj)
        if bad_weight:add('ERROR','WEIGHT_FINITE','顶点权重包含无效值',obj)
        for group in obj.vertex_groups:
            if group.name not in bone_names and group.index in used:add('WARNING','WEIGHT_GROUP','非骨骼顶点组：'+group.name,obj,group.name)
        if any(poly.material_index>=len(obj.material_slots) or obj.material_slots[poly.material_index].material is None for poly in obj.data.polygons):add('WARNING','MATERIAL_SLOT','部分面未分配有效材质',obj)
        materials.update(slot.material for slot in obj.material_slots if slot.material)
        keys=obj.data.shape_keys
        if keys:
            for key in keys.key_blocks:
                if key==keys.reference_key:continue
                shape_names.add(key.name)
                if any(not all(math.isfinite(c) for c in point.co) for point in key.data):add('ERROR','MORPH_FINITE','表情存在无效坐标：'+key.name,obj,key.name)
                elif all((a.co-b.co).length_squared<1e-14 for a,b in zip(key.data,key.relative_key.data)):add('WARNING','MORPH_EMPTY','空表情：'+key.name,obj,key.name)
                if metadata(root,'vertex_morphs',key.name) is None:
                    category=(shape_category(obj,key.name) or {}).get('category',guess_category(key.name))
                    if category=='OTHER':add('WARNING','MORPH_UNKNOWN','无法识别分类：'+key.name+' → 其他',obj,key.name)
                    else:add('WARNING','MORPH_UNSET','未设置分类：'+key.name+' → '+next(c[1] for c in CATEGORIES if c[0]==category),obj,key.name)
    for kind in MORPH_TYPES:
        for morph in getattr(root.mmd_root,kind):
            morph_names.setdefault(morph.name,[]).append(kind)
            if kind!='vertex_morphs' and not morph.data:add('WARNING','MORPH_EMPTY','空表情：'+morph.name,root,morph.name)
            if kind=='vertex_morphs' and morph.category=='OTHER' and morph.get('clm_category_source')=='AUTO':add('WARNING','MORPH_UNKNOWN','自动归入其他，请确认：'+morph.name,root,morph.name)
            if kind=='vertex_morphs' and morph.name not in shape_names:add('WARNING','MORPH_STALE','表情记录找不到形态键：'+morph.name,root,morph.name)
            if kind=='group_morphs':
                for entry in morph.data:
                    if entry.morph_type not in MORPH_TYPES or metadata(root,entry.morph_type,entry.name) is None:add('ERROR','MORPH_LINK','组合表情引用无效：'+morph.name,root,morph.name)
    for name,kinds in morph_names.items():
        if len(kinds)>1:add('WARNING','MORPH_NAME','不同类型表情重名：'+name,root,name)
    material_api=None
    for package in ('bl_ext.blender_org.mmd_tools','mmd_tools'):
        try:material_api=importlib.import_module(package+'.core.material');break
        except ImportError:pass
    for mat in materials:
        settings=getattr(mat,'mmd_material',None);toon_image=None
        if material_api:
            helper=material_api.FnMaterial(mat);images=[]
            for method in ('get_texture','get_sphere_texture','get_toon_texture'):
                texture=getattr(helper,method)();image=getattr(texture,'image',None) if texture else None
                if method=='get_toon_texture':toon_image=image
                if image:images.append(image)
        else:images=[node.image for node in mat.node_tree.nodes if getattr(node,'image',None)] if mat.use_nodes else []
        for image in set(images):
                if image.source in {'TILED','SEQUENCE','MOVIE'}:add('ERROR','TEXTURE_TYPE','导出不支持此贴图类型：'+image.name,root)
                elif image.source=='FILE' and not image.packed_file and not image.is_dirty and not Path(bpy.path.abspath(image.filepath,library=image.library)).is_file():add('ERROR','TEXTURE_MISSING','贴图文件缺失：'+image.name,root)
        if settings and not settings.is_shared_toon_texture and settings.toon_texture and not toon_image and not Path(bpy.path.abspath(settings.toon_texture,library=mat.library)).is_file():add('ERROR','TOON_MISSING','Toon 贴图缺失：'+mat.name,root)
    rigids={o for o in children if getattr(o,'mmd_type','')=='RIGID_BODY'}
    for body in rigids:
        settings=body.mmd_rigid
        if settings.bone and settings.bone not in bone_names:add('ERROR','RIGID_BONE','刚体骨骼引用无效：'+body.name,body,settings.bone)
        if not settings.bone:add('WARNING','RIGID_UNBOUND','刚体未关联骨骼：'+body.name,body)
        if not body.rigid_body:add('ERROR','RIGID_DATA','刚体缺少物理数据：'+body.name,body)
        elif any(not math.isfinite(getattr(body.rigid_body,key)) or getattr(body.rigid_body,key)<0 for key in ('mass','friction','restitution','linear_damping','angular_damping')):add('ERROR','RIGID_PARAMETERS','刚体物理参数无效：'+body.name,body)
        if any(not math.isfinite(x) or x<0 for x in settings.size):add('ERROR','RIGID_SIZE','刚体尺寸无效：'+body.name,body)
    for joint in (o for o in children if getattr(o,'mmd_type','')=='JOINT'):
        con=joint.rigid_body_constraint
        if not con or con.object1 not in rigids or con.object2 not in rigids or con.object1==con.object2:add('ERROR','JOINT_LINK','Joint 两端刚体引用无效：'+joint.name,joint)
        if con:
            limits=[getattr(con,'limit_'+axis+'_'+side) for axis in ('lin_x','lin_y','lin_z','ang_x','ang_y','ang_z') for side in ('lower','upper')]
            if any(not math.isfinite(x) for x in limits):add('ERROR','JOINT_FINITE','Joint 限制包含无效数值：'+joint.name,joint)
            elif any(getattr(con,'limit_'+axis+'_lower')>getattr(con,'limit_'+axis+'_upper') for axis in ('lin_x','lin_y','lin_z','ang_x','ang_y','ang_z')):add('ERROR','JOINT_RANGE','Joint 下限大于上限：'+joint.name,joint)
        if any(not math.isfinite(x) or x<0 for x in (*joint.mmd_joint.spring_linear,*joint.mmd_joint.spring_angular)):add('ERROR','JOINT_SPRING','Joint 弹簧参数无效：'+joint.name,joint)
    return report(issues)

def report(issues):
    return {'issues':issues,'errors':sum(x['severity']=='ERROR' for x in issues),'warnings':sum(x['severity']=='WARNING' for x in issues)}
